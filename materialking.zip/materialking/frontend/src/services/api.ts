import axios from "axios"

export const api = axios.create({
  baseURL: "http://localhost:5000/api",
  withCredentials: true,
})

api.interceptors.request.use((config) => {
  const token = localStorage.getItem("accessToken")
  if (token) {
    config.headers.Authorization = `Bearer ${token}`
  }
  return config
})

// Auto-refresh expired access tokens
let isRefreshing = false
let failedQueue: Array<{ resolve: (token: string) => void; reject: (err: any) => void }> = []

const processQueue = (error: any, token: string | null) => {
  failedQueue.forEach((p) => (error ? p.reject(error) : p.resolve(token!)))
  failedQueue = []
}

api.interceptors.response.use(
  (response) => {
<<<<<<< HEAD
    // Auto-unwrap paginated responses: { data: [...], pagination: {...} } → [...]
    // so existing code using response.data still gets an array
    const body = response.data;
    if (body && !Array.isArray(body) && Array.isArray(body.data) && body.pagination) {
      response.data = body.data;
      response.headers['x-pagination'] = JSON.stringify(body.pagination);
=======
    // Unwrap paginated responses so .data returns the array directly
    if (response.data && Array.isArray(response.data.data) && response.data.pagination) {
      response.data = response.data.data;
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
    }
    return response;
  },
  async (error) => {
    const originalRequest = error.config

    if (error.response?.status === 401 && !originalRequest._retry) {
      const refreshToken = localStorage.getItem("refreshToken")
      if (!refreshToken) {
        localStorage.removeItem("accessToken")
        localStorage.removeItem("refreshToken")
        window.location.href = "/login"
        return Promise.reject(error)
      }

      if (isRefreshing) {
        return new Promise((resolve, reject) => {
          failedQueue.push({ resolve, reject })
        }).then((token) => {
          originalRequest.headers.Authorization = `Bearer ${token}`
          return api(originalRequest)
        })
      }

      originalRequest._retry = true
      isRefreshing = true

      try {
        const { data } = await axios.post("http://localhost:5000/api/auth/refresh", { refreshToken })
        localStorage.setItem("accessToken", data.accessToken)
        localStorage.setItem("refreshToken", data.refreshToken)
        api.defaults.headers.common.Authorization = `Bearer ${data.accessToken}`
        processQueue(null, data.accessToken)
        originalRequest.headers.Authorization = `Bearer ${data.accessToken}`
        return api(originalRequest)
      } catch (refreshError) {
        processQueue(refreshError, null)
        localStorage.removeItem("accessToken")
        localStorage.removeItem("refreshToken")
        window.location.href = "/login"
        return Promise.reject(refreshError)
      } finally {
        isRefreshing = false
      }
    }

    return Promise.reject(error)
  }
)
