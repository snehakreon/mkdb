import { Request } from "express";

export interface PaginationParams {
  page: number;
<<<<<<< HEAD
  limit: number;
  offset: number;
  search?: string;
=======
  pageSize: number;
  offset: number;
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
}

export interface PaginatedResponse<T> {
  data: T[];
  pagination: {
    page: number;
<<<<<<< HEAD
    limit: number;
=======
    pageSize: number;
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
    total: number;
    totalPages: number;
  };
}

<<<<<<< HEAD
/**
 * Extract pagination params from request query.
 * Defaults: page=1, limit=20, max limit=100
 */
export function getPaginationParams(req: Request): PaginationParams {
  const page = Math.max(1, parseInt(req.query.page as string) || 1);
  const limit = Math.min(100, Math.max(1, parseInt(req.query.limit as string) || 20));
  const offset = (page - 1) * limit;
  const search = (req.query.search as string) || undefined;

  return { page, limit, offset, search };
}

/**
 * Build a paginated response envelope.
 */
export function paginatedResponse<T>(
=======
export function parsePagination(req: Request, defaultPageSize = 20): PaginationParams {
  const page = Math.max(1, parseInt(req.query.page as string) || 1);
  const pageSize = Math.min(100, Math.max(1, parseInt(req.query.pageSize as string) || defaultPageSize));
  const offset = (page - 1) * pageSize;
  return { page, pageSize, offset };
}

export function buildPaginatedResponse<T>(
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
  data: T[],
  total: number,
  params: PaginationParams
): PaginatedResponse<T> {
  return {
    data,
    pagination: {
      page: params.page,
<<<<<<< HEAD
      limit: params.limit,
      total,
      totalPages: Math.ceil(total / params.limit),
=======
      pageSize: params.pageSize,
      total,
      totalPages: Math.ceil(total / params.pageSize),
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
    },
  };
}
