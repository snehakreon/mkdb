import { Router, Request, Response, NextFunction } from "express";
<<<<<<< HEAD
import { authenticate } from "../../middleware/auth.middleware";
import { uploadImage, uploadImages, uploadDocument, setUploadFolder, UPLOAD_DIR } from "../../middleware/upload.middleware";

const router = Router();

// POST /api/upload/image/:folder — single image
router.post(
  "/image/:folder",
  authenticate,
  (req: Request, res: Response, next: NextFunction) => {
    const folder = req.params.folder;
    setUploadFolder(folder)(req, res, () => {
      uploadImage(req, res, (err: any) => {
        if (err) {
          return res.status(400).json({ message: err.message });
        }
        if (!req.file) {
          return res.status(400).json({ message: "No file uploaded" });
        }
        const fileUrl = `/uploads/${folder}/${req.file.filename}`;
        res.json({ url: fileUrl, filename: req.file.filename });
      });
=======
import { upload } from "./upload.middleware";
import { authenticate } from "../../middleware/auth.middleware";

const router = Router();

// POST /api/upload — single file upload
router.post(
  "/",
  authenticate,
  (req: Request, res: Response, next: NextFunction) => {
    upload.single("file")(req, res, (err) => {
      if (err) {
        const status = err.message.includes("not allowed") ? 400 : 413;
        return res.status(status).json({ message: err.message });
      }
      next();
    });
  },
  (req: Request, res: Response) => {
    if (!req.file) {
      return res.status(400).json({ message: "No file uploaded" });
    }
    const fileUrl = `/uploads/${req.file.filename}`;
    res.status(201).json({
      url: fileUrl,
      filename: req.file.filename,
      originalName: req.file.originalname,
      size: req.file.size,
      mimetype: req.file.mimetype,
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
    });
  }
);

<<<<<<< HEAD
// POST /api/upload/images/:folder — multiple images (up to 10)
router.post(
  "/images/:folder",
  authenticate,
  (req: Request, res: Response, next: NextFunction) => {
    const folder = req.params.folder;
    setUploadFolder(folder)(req, res, () => {
      uploadImages(req, res, (err: any) => {
        if (err) {
          return res.status(400).json({ message: err.message });
        }
        const files = req.files as Express.Multer.File[];
        if (!files || files.length === 0) {
          return res.status(400).json({ message: "No files uploaded" });
        }
        const urls = files.map((f) => ({
          url: `/uploads/${folder}/${f.filename}`,
          filename: f.filename,
        }));
        res.json({ files: urls });
      });
    });
  }
);

// POST /api/upload/document/:folder — single document (PDF/image)
router.post(
  "/document/:folder",
  authenticate,
  (req: Request, res: Response, next: NextFunction) => {
    const folder = req.params.folder;
    setUploadFolder(folder)(req, res, () => {
      uploadDocument(req, res, (err: any) => {
        if (err) {
          return res.status(400).json({ message: err.message });
        }
        if (!req.file) {
          return res.status(400).json({ message: "No file uploaded" });
        }
        const fileUrl = `/uploads/${folder}/${req.file.filename}`;
        res.json({ url: fileUrl, filename: req.file.filename });
      });
    });
=======
// POST /api/upload/multiple — up to 10 files
router.post(
  "/multiple",
  authenticate,
  (req: Request, res: Response, next: NextFunction) => {
    upload.array("files", 10)(req, res, (err) => {
      if (err) {
        const status = err.message.includes("not allowed") ? 400 : 413;
        return res.status(status).json({ message: err.message });
      }
      next();
    });
  },
  (req: Request, res: Response) => {
    const files = req.files as Express.Multer.File[];
    if (!files || files.length === 0) {
      return res.status(400).json({ message: "No files uploaded" });
    }
    const results = files.map((f) => ({
      url: `/uploads/${f.filename}`,
      filename: f.filename,
      originalName: f.originalname,
      size: f.size,
      mimetype: f.mimetype,
    }));
    res.status(201).json(results);
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
  }
);

export default router;
