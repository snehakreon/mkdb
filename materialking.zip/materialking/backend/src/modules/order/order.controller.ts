import { Request, Response } from "express";
import { AuthRequest } from "../../middleware/auth.middleware";
import pool from "../../config/db";
<<<<<<< HEAD
import { getPaginationParams, paginatedResponse } from "../../utils/pagination";
import { validateTransition, getNextStatuses } from "../../utils/orderStateMachine";
import { decrementInventory, restoreInventory } from "../../utils/inventory";
=======
import { parsePagination, buildPaginatedResponse } from "../../utils/pagination";
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611

// GET /api/orders (admin: all, buyer: own)
export const getAll = async (req: Request, res: Response) => {
  try {
<<<<<<< HEAD
    const { page, limit, offset, search } = getPaginationParams(req);
    const { status } = req.query;
    const params: any[] = [];
    let paramIdx = 1;
    const conditions: string[] = [];

=======
    const { search, status } = req.query;
    const pag = parsePagination(req);
    let where = "";
    const params: any[] = [];
    let paramIdx = 1;

    const conditions: string[] = [];
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
    if (search) {
      conditions.push(`(o.order_number ILIKE $${paramIdx} OR b.company_name ILIKE $${paramIdx})`);
      params.push(`%${search}%`);
      paramIdx++;
    }
    if (status) {
<<<<<<< HEAD
      conditions.push(`o.status = $${paramIdx++}`);
      params.push(status);
    }

    const where = conditions.length > 0 ? ` WHERE ${conditions.join(" AND ")}` : "";

    const countResult = await pool.query(
      `SELECT COUNT(*) FROM orders o
       LEFT JOIN buyers b ON o.buyer_id = b.id${where}`,
      params
=======
      conditions.push(`o.status = $${paramIdx}`);
      params.push(status);
      paramIdx++;
    }
    if (conditions.length > 0) {
      where = ` WHERE ${conditions.join(" AND ")}`;
    }

    const countResult = await pool.query(
      `SELECT COUNT(*) FROM orders o LEFT JOIN buyers b ON o.buyer_id = b.id${where}`, params
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
    );
    const total = parseInt(countResult.rows[0].count);

    const result = await pool.query(
      `SELECT o.id, o.order_number, o.status, o.payment_method, o.payment_status,
              o.total_amount, o.shipping_address, o.notes, o.created_at, o.updated_at,
              o.buyer_id, o.dealer_id, o.vendor_id,
              b.company_name AS buyer_company, b.contact_name AS buyer_contact,
              d.company_name AS dealer_company,
              v.company_name AS vendor_company
       FROM orders o
       LEFT JOIN buyers b ON o.buyer_id = b.id
       LEFT JOIN dealers d ON o.dealer_id = d.id
<<<<<<< HEAD
       LEFT JOIN vendors v ON o.vendor_id = v.id${where}
       ORDER BY o.created_at DESC
       LIMIT $${paramIdx++} OFFSET $${paramIdx++}`,
      [...params, limit, offset]
    );
    res.json(paginatedResponse(result.rows, total, { page, limit, offset }));
=======
       LEFT JOIN vendors v ON o.vendor_id = v.id
       ${where}
       ORDER BY o.created_at DESC
       LIMIT $${paramIdx} OFFSET $${paramIdx + 1}`,
      [...params, pag.pageSize, pag.offset]
    );
    res.json(buildPaginatedResponse(result.rows, total, pag));
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
  } catch (error: any) {
    console.error("Order getAll error:", error);
    res.status(500).json({ message: error.message });
  }
};

// GET /api/orders/my — buyer's own orders
export const getMyOrders = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const pag = parsePagination(req);

    const countResult = await pool.query(
      `SELECT COUNT(*) FROM orders o JOIN buyers b ON o.buyer_id = b.id WHERE b.user_id = $1`,
      [userId]
    );
    const total = parseInt(countResult.rows[0].count);

    const result = await pool.query(
      `SELECT o.id, o.order_number, o.status, o.payment_method, o.payment_status,
              o.total_amount, o.shipping_address, o.notes, o.created_at, o.updated_at,
              (SELECT COUNT(*) FROM order_items oi WHERE oi.order_id = o.id) AS item_count
       FROM orders o
       JOIN buyers b ON o.buyer_id = b.id
       WHERE b.user_id = $1
       ORDER BY o.created_at DESC
       LIMIT $2 OFFSET $3`,
      [userId, pag.pageSize, pag.offset]
    );
    res.json(buildPaginatedResponse(result.rows, total, pag));
  } catch (error: any) {
    console.error("Order getMyOrders error:", error);
    res.status(500).json({ message: error.message });
  }
};

// GET /api/orders/my/:id — buyer's own order detail
export const getMyOrderDetail = async (req: AuthRequest, res: Response) => {
  try {
    const userId = req.user!.userId;
    const { id } = req.params;

    const orderResult = await pool.query(
      `SELECT o.id, o.order_number, o.status, o.payment_method, o.payment_status,
              o.total_amount, o.shipping_address, o.notes, o.created_at, o.updated_at
       FROM orders o
       JOIN buyers b ON o.buyer_id = b.id
       WHERE o.id = $1 AND b.user_id = $2`,
      [id, userId]
    );
    if (orderResult.rows.length === 0) {
      return res.status(404).json({ message: "Order not found" });
    }

    const itemsResult = await pool.query(
      `SELECT oi.id, oi.product_id, oi.quantity, oi.unit_price, oi.total_price,
              p.name AS product_name, p.sku, p.image_url, p.unit
       FROM order_items oi
       LEFT JOIN products p ON oi.product_id = p.id
       WHERE oi.order_id = $1`,
      [id]
    );

    res.json({ ...orderResult.rows[0], items: itemsResult.rows });
  } catch (error: any) {
    console.error("Order getMyOrderDetail error:", error);
    res.status(500).json({ message: error.message });
  }
};

// GET /api/orders/:id
export const getById = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const orderResult = await pool.query(
      `SELECT o.id, o.order_number, o.status, o.payment_method, o.payment_status,
              o.total_amount, o.shipping_address, o.notes, o.created_at, o.updated_at,
              o.buyer_id, o.dealer_id, o.vendor_id,
              b.company_name AS buyer_company, b.contact_name AS buyer_contact,
              d.company_name AS dealer_company,
              v.company_name AS vendor_company
       FROM orders o
       LEFT JOIN buyers b ON o.buyer_id = b.id
       LEFT JOIN dealers d ON o.dealer_id = d.id
       LEFT JOIN vendors v ON o.vendor_id = v.id
       WHERE o.id = $1`,
      [id]
    );
    if (orderResult.rows.length === 0) {
      return res.status(404).json({ message: "Order not found" });
    }

    const itemsResult = await pool.query(
      `SELECT oi.id, oi.order_id, oi.product_id, oi.quantity, oi.unit_price, oi.total_price,
              p.name AS product_name, p.sku
       FROM order_items oi
       LEFT JOIN products p ON oi.product_id = p.id
       WHERE oi.order_id = $1`,
      [id]
    );

    res.json({ ...orderResult.rows[0], items: itemsResult.rows });
  } catch (error: any) {
    console.error("Order getById error:", error);
    res.status(500).json({ message: error.message });
  }
};

// POST /api/orders
export const create = async (req: AuthRequest, res: Response) => {
  const client = await pool.connect();
  try {
    const userId = req.user?.userId;
    const { buyer_id, dealer_id, vendor_id, shipping_address, notes, items, payment_method } = req.body;

    await client.query("BEGIN");

    // Auto-resolve buyer_id from logged-in user if not provided
    let resolvedBuyerId = buyer_id || null;
    if (!resolvedBuyerId && userId) {
      const buyerResult = await client.query(
        `SELECT id FROM buyers WHERE user_id = $1 AND is_active = true LIMIT 1`,
        [userId]
      );
      if (buyerResult.rows.length > 0) {
        resolvedBuyerId = buyerResult.rows[0].id;
      }
    }

    // Validate stock availability and lock rows (FOR UPDATE prevents concurrent overselling)
    if (items && items.length > 0) {
      for (const item of items) {
        const stockResult = await client.query(
          `SELECT id, name, stock_qty, min_order_qty FROM products WHERE id = $1 FOR UPDATE`,
          [item.product_id]
        );
        if (stockResult.rows.length === 0) {
          await client.query("ROLLBACK");
          return res.status(400).json({ message: `Product ${item.product_id} not found` });
        }
        const product = stockResult.rows[0];
        if (item.quantity < product.min_order_qty) {
          await client.query("ROLLBACK");
          return res.status(400).json({
            message: `Minimum order quantity for "${product.name}" is ${product.min_order_qty}`,
          });
        }
        if (product.stock_qty < item.quantity) {
          await client.query("ROLLBACK");
          return res.status(400).json({
            message: `Insufficient stock for "${product.name}". Available: ${product.stock_qty}, requested: ${item.quantity}`,
          });
        }
      }
    }

    // Generate order number
    const countResult = await client.query("SELECT COUNT(*) FROM orders");
    const orderNum = String(Number(countResult.rows[0].count) + 1).padStart(7, "0");
    const order_number = `ORD-${orderNum}`;

    // Calculate total from items
    let total_amount = 0;
    if (items && items.length > 0) {
      for (const item of items) {
        total_amount += item.quantity * item.unit_price;
      }
    }

    const orderResult = await client.query(
      `INSERT INTO orders (order_number, buyer_id, dealer_id, vendor_id, status,
                           payment_method, payment_status, total_amount, shipping_address, notes)
       VALUES ($1, $2, $3, $4, 'pending', $5, $6, $7, $8, $9)
       RETURNING *`,
      [order_number, resolvedBuyerId, dealer_id || null, vendor_id || null,
       payment_method || "cod",
       payment_method === "cod" ? "unpaid" : "unpaid",
       total_amount, shipping_address || null, notes || null]
    );

    const order_id = orderResult.rows[0].id;

    // Insert order items and decrement stock
    if (items && items.length > 0) {
      for (const item of items) {
        const total_price = item.quantity * item.unit_price;
        await client.query(
          `INSERT INTO order_items (order_id, product_id, quantity, unit_price, total_price)
           VALUES ($1, $2, $3, $4, $5)`,
          [order_id, item.product_id, item.quantity, item.unit_price, total_price]
        );

        // Decrement stock
        await client.query(
          `UPDATE products SET stock_qty = stock_qty - $1, updated_at = NOW() WHERE id = $2`,
          [item.quantity, item.product_id]
        );
      }
    }

    // Decrement inventory for each item (never rejects — back-orders if needed)
    let inventoryResult: any = null;
    if (items && items.length > 0) {
      inventoryResult = await decrementInventory(
        client,
        items.map((i: any) => ({ product_id: i.product_id, quantity: i.quantity })),
        order_id,
        userId
      );

      // Set expected delivery date on the order
      await client.query(
        `UPDATE orders SET expected_delivery_date = $1 WHERE id = $2`,
        [inventoryResult.expected_delivery_date, order_id]
      );
    }

    // Clear the user's cart after successful order
    if (userId) {
      await client.query(`DELETE FROM cart_items WHERE user_id = $1`, [userId]);
    }

    await client.query("COMMIT");

    // Re-fetch order with updated expected_delivery_date
    const finalOrder = await pool.query(`SELECT * FROM orders WHERE id = $1`, [order_id]);

    const response: any = {
      ...finalOrder.rows[0],
      ...(inventoryResult && {
        fulfillment: inventoryResult.fulfillment,
        has_back_order: inventoryResult.has_back_order,
        expected_delivery_date: inventoryResult.expected_delivery_date,
      }),
      ...(inventoryResult?.low_stock_alerts?.length > 0 && {
        low_stock_alerts: inventoryResult.low_stock_alerts,
      }),
    };
    res.status(201).json(response);
  } catch (error: any) {
    await client.query("ROLLBACK");
    console.error("Order create error:", error);
    res.status(500).json({ message: error.message });
  } finally {
    client.release();
  }
};

<<<<<<< HEAD
// PUT /api/orders/:id (update fields — status change uses state machine)
export const update = async (req: AuthRequest, res: Response) => {
=======
// Valid state transitions for the order workflow
const VALID_TRANSITIONS: Record<string, string[]> = {
  pending:    ["confirmed", "cancelled"],
  confirmed:  ["processing", "cancelled"],
  processing: ["shipped", "cancelled"],
  shipped:    ["delivered"],
  delivered:  [],
  cancelled:  [],
};

// PUT /api/orders/:id
export const update = async (req: Request, res: Response) => {
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
  const client = await pool.connect();
  try {
    const { id } = req.params;
    const { status, total_amount, shipping_address, notes, vendor_id, payment_status } = req.body;

    await client.query("BEGIN");

<<<<<<< HEAD
    // If status change requested, validate via state machine
    if (status) {
      const currentResult = await client.query(
        "SELECT status FROM orders WHERE id = $1 FOR UPDATE",
        [id]
      );
      if (currentResult.rows.length === 0) {
        await client.query("ROLLBACK");
        return res.status(404).json({ message: "Order not found" });
      }

      const currentStatus = currentResult.rows[0].status;
      const validation = validateTransition(currentStatus, status);
      if (!validation.valid) {
        await client.query("ROLLBACK");
        return res.status(400).json({ message: validation.message });
      }

      // Log status change in order_status_history
      await client.query(
        `INSERT INTO order_status_history (order_id, from_status, to_status, changed_by, notes)
         VALUES ($1, $2, $3, $4, $5)`,
        [id, currentStatus, status, req.user?.userId || null, notes || null]
      );
=======
    // If status is being changed, validate transition
    if (status) {
      const current = await client.query(`SELECT status FROM orders WHERE id = $1 FOR UPDATE`, [id]);
      if (current.rows.length === 0) {
        await client.query("ROLLBACK");
        return res.status(404).json({ message: "Order not found" });
      }
      const currentStatus = current.rows[0].status;
      const allowed = VALID_TRANSITIONS[currentStatus] || [];
      if (!allowed.includes(status)) {
        await client.query("ROLLBACK");
        return res.status(400).json({
          message: `Cannot transition from '${currentStatus}' to '${status}'. Allowed: ${allowed.join(", ") || "none (terminal state)"}`,
        });
      }

      // Restore stock if cancelling
      if (status === "cancelled") {
        const orderItems = await client.query(
          `SELECT product_id, quantity FROM order_items WHERE order_id = $1`,
          [id]
        );
        for (const item of orderItems.rows) {
          await client.query(
            `UPDATE products SET stock_qty = stock_qty + $1, updated_at = NOW() WHERE id = $2`,
            [item.quantity, item.product_id]
          );
        }
      }
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
    }

    const result = await client.query(
      `UPDATE orders SET
        status = COALESCE($1, status),
        total_amount = COALESCE($2, total_amount),
        shipping_address = COALESCE($3, shipping_address),
        notes = COALESCE($4, notes),
        vendor_id = COALESCE($5, vendor_id),
        payment_status = COALESCE($6, payment_status),
        updated_at = NOW()
       WHERE id = $7
       RETURNING *`,
      [status, total_amount, shipping_address, notes, vendor_id, payment_status, id]
    );
    if (result.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({ message: "Order not found" });
    }

    await client.query("COMMIT");
    res.json(result.rows[0]);
  } catch (error: any) {
    await client.query("ROLLBACK");
    console.error("Order update error:", error);
    res.status(500).json({ message: error.message });
  } finally {
    client.release();
<<<<<<< HEAD
  }
};

// POST /api/orders/:id/transition — dedicated status transition endpoint
export const transitionStatus = async (req: AuthRequest, res: Response) => {
  const client = await pool.connect();
  try {
    const { id } = req.params;
    const { status, notes } = req.body;

    if (!status) {
      return res.status(400).json({ message: "Target status is required" });
    }

    await client.query("BEGIN");

    const currentResult = await client.query(
      "SELECT id, order_number, status FROM orders WHERE id = $1 FOR UPDATE",
      [id]
    );
    if (currentResult.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({ message: "Order not found" });
    }

    const order = currentResult.rows[0];
    const validation = validateTransition(order.status, status);
    if (!validation.valid) {
      await client.query("ROLLBACK");
      return res.status(400).json({
        message: validation.message,
        current_status: order.status,
        allowed_transitions: getNextStatuses(order.status),
      });
    }

    // Log the transition
    await client.query(
      `INSERT INTO order_status_history (order_id, from_status, to_status, changed_by, notes)
       VALUES ($1, $2, $3, $4, $5)`,
      [id, order.status, status, req.user?.userId || null, notes || null]
    );

    const result = await client.query(
      `UPDATE orders SET status = $1, updated_at = NOW() WHERE id = $2 RETURNING *`,
      [status, id]
    );

    await client.query("COMMIT");
    res.json({
      ...result.rows[0],
      previous_status: order.status,
      allowed_transitions: getNextStatuses(status),
    });
  } catch (error: any) {
    await client.query("ROLLBACK");
    console.error("Order transition error:", error);
    res.status(500).json({ message: error.message });
  } finally {
    client.release();
  }
};

// GET /api/orders/:id/history — get status change history
export const getStatusHistory = async (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const result = await pool.query(
      `SELECT osh.id, osh.from_status, osh.to_status, osh.notes, osh.created_at,
              u.email AS changed_by_email
       FROM order_status_history osh
       LEFT JOIN users u ON osh.changed_by = u.id
       WHERE osh.order_id = $1
       ORDER BY osh.created_at ASC`,
      [id]
    );
    res.json(result.rows);
  } catch (error: any) {
    console.error("Order history error:", error);
    res.status(500).json({ message: error.message });
  }
};

// DELETE /api/orders/:id (cancel order + restore inventory)
export const remove = async (req: Request, res: Response) => {
  const client = await pool.connect();
  try {
    const { id } = req.params;

    await client.query("BEGIN");

    const result = await client.query(
      `UPDATE orders SET status = 'cancelled', updated_at = NOW()
       WHERE id = $1 AND status NOT IN ('delivered', 'cancelled')
       RETURNING id, order_number, status`,
      [id]
    );
    if (result.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({ message: "Order not found or cannot be cancelled" });
    }

    // Restore inventory for cancelled order
    await restoreInventory(client, id);

    // Log cancellation in history
    await client.query(
      `INSERT INTO order_status_history (order_id, from_status, to_status, notes)
       VALUES ($1, $2, 'cancelled', 'Order cancelled')`,
      [id, result.rows[0].status === "cancelled" ? "pending" : result.rows[0].status]
    );

    await client.query("COMMIT");
    res.json({ message: "Order cancelled, inventory restored", order: result.rows[0] });
=======
  }
};

// PUT /api/orders/:id/status — dedicated status transition endpoint
export const updateStatus = async (req: Request, res: Response) => {
  const client = await pool.connect();
  try {
    const { id } = req.params;
    const { status } = req.body;

    if (!status) {
      return res.status(400).json({ message: "status is required" });
    }

    await client.query("BEGIN");

    const current = await client.query(`SELECT id, status, order_number FROM orders WHERE id = $1 FOR UPDATE`, [id]);
    if (current.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({ message: "Order not found" });
    }

    const currentStatus = current.rows[0].status;
    const allowed = VALID_TRANSITIONS[currentStatus] || [];
    if (!allowed.includes(status)) {
      await client.query("ROLLBACK");
      return res.status(400).json({
        message: `Cannot transition from '${currentStatus}' to '${status}'. Allowed: ${allowed.join(", ") || "none (terminal state)"}`,
        current_status: currentStatus,
        allowed_transitions: allowed,
      });
    }

    // Restore stock if cancelling
    if (status === "cancelled") {
      const orderItems = await client.query(
        `SELECT product_id, quantity FROM order_items WHERE order_id = $1`,
        [id]
      );
      for (const item of orderItems.rows) {
        await client.query(
          `UPDATE products SET stock_qty = stock_qty + $1, updated_at = NOW() WHERE id = $2`,
          [item.quantity, item.product_id]
        );
      }
    }

    const result = await client.query(
      `UPDATE orders SET status = $1, updated_at = NOW() WHERE id = $2 RETURNING *`,
      [status, id]
    );

    await client.query("COMMIT");
    res.json(result.rows[0]);
  } catch (error: any) {
    await client.query("ROLLBACK");
    console.error("Order updateStatus error:", error);
    res.status(500).json({ message: error.message });
  } finally {
    client.release();
  }
};

// DELETE /api/orders/:id (cancel order + restore stock)
export const remove = async (req: Request, res: Response) => {
  const client = await pool.connect();
  try {
    const { id } = req.params;

    await client.query("BEGIN");

    const current = await client.query(`SELECT id, status FROM orders WHERE id = $1 FOR UPDATE`, [id]);
    if (current.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(404).json({ message: "Order not found" });
    }
    const allowed = VALID_TRANSITIONS[current.rows[0].status] || [];
    if (!allowed.includes("cancelled")) {
      await client.query("ROLLBACK");
      return res.status(400).json({
        message: `Cannot cancel order in '${current.rows[0].status}' state`,
      });
    }

    // Restore stock for each order item
    const orderItems = await client.query(
      `SELECT product_id, quantity FROM order_items WHERE order_id = $1`,
      [id]
    );
    for (const item of orderItems.rows) {
      await client.query(
        `UPDATE products SET stock_qty = stock_qty + $1, updated_at = NOW() WHERE id = $2`,
        [item.quantity, item.product_id]
      );
    }

    const result = await client.query(
      `UPDATE orders SET status = 'cancelled', updated_at = NOW()
       WHERE id = $1
       RETURNING id, order_number`,
      [id]
    );

    await client.query("COMMIT");
    res.json({ message: "Order cancelled, stock restored", order: result.rows[0] });
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
  } catch (error: any) {
    await client.query("ROLLBACK");
    console.error("Order cancel error:", error);
    res.status(500).json({ message: error.message });
  } finally {
    client.release();
  }
};
