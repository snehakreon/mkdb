import { Router } from "express";
import { authenticate } from "../../middleware/auth.middleware";
<<<<<<< HEAD
import {
  getAll, getById, create, update, remove,
  getMyOrders, getMyOrderDetail,
  transitionStatus, getStatusHistory
} from "./order.controller";
=======
import { getAll, getById, create, update, updateStatus, remove, getMyOrders, getMyOrderDetail } from "./order.controller";
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611

const router = Router();

// Buyer's own orders (auth required)
router.get("/my", authenticate, getMyOrders);
router.get("/my/:id", authenticate, getMyOrderDetail);

// General CRUD
router.get("/", getAll);
router.get("/:id", getById);
router.post("/", authenticate, create);
<<<<<<< HEAD
router.put("/:id", authenticate, update);
=======
router.put("/:id", update);
router.put("/:id/status", updateStatus);
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
router.delete("/:id", remove);

// Order workflow
router.post("/:id/transition", authenticate, transitionStatus);
router.get("/:id/history", getStatusHistory);

export default router;
