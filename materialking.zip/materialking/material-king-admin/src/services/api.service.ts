import axios from 'axios';
import { API_CONFIG } from '../config/api.config';

const apiClient = axios.create({
  baseURL: API_CONFIG.API_BASE_URL,
  timeout: API_CONFIG.TIMEOUT,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor
apiClient.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('mk_auth_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

<<<<<<< HEAD
// Token refresh state to prevent multiple simultaneous refresh calls
let isRefreshing = false;
let failedQueue: Array<{ resolve: (token: string) => void; reject: (err: any) => void }> = [];

const processQueue = (error: any, token: string | null = null) => {
  failedQueue.forEach(({ resolve, reject }) => {
    if (token) resolve(token);
    else reject(error);
  });
  failedQueue = [];
};

// Response interceptor with automatic token refresh
=======
// Response interceptor — auto-refresh expired tokens
let isRefreshing = false;
let failedQueue: Array<{ resolve: (token: string) => void; reject: (err: any) => void }> = [];

const processQueue = (error: any, token: string | null) => {
  failedQueue.forEach((p) => (error ? p.reject(error) : p.resolve(token!)));
  failedQueue = [];
};

>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
apiClient.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;

<<<<<<< HEAD
    // Only attempt refresh on 401 errors, and not on the refresh endpoint itself
    if (error.response?.status === 401 && !originalRequest._retry && !originalRequest.url?.includes('/auth/refresh')) {
      if (isRefreshing) {
        // Queue this request until refresh completes
        return new Promise((resolve, reject) => {
          failedQueue.push({
            resolve: (token: string) => {
              originalRequest.headers.Authorization = `Bearer ${token}`;
              resolve(apiClient(originalRequest));
            },
            reject,
          });
        });
      }

      originalRequest._retry = true;
      isRefreshing = true;

      const refreshToken = localStorage.getItem('mk_refresh_token');
      if (!refreshToken) {
        isRefreshing = false;
        processQueue(error, null);
        // No refresh token — force logout
=======
    if (error.response?.status === 401 && !originalRequest._retry) {
      const refreshToken = localStorage.getItem('mk_refresh_token');
      if (!refreshToken) {
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
        localStorage.removeItem('mk_auth_token');
        localStorage.removeItem('mk_refresh_token');
        localStorage.removeItem('mk_user');
        window.location.reload();
        return Promise.reject(error);
      }

<<<<<<< HEAD
      try {
        const { data } = await axios.post(`${API_CONFIG.API_BASE_URL}/auth/refresh`, { refreshToken });
        const newAccessToken = data.accessToken;

        localStorage.setItem('mk_auth_token', newAccessToken);
        if (data.refreshToken) {
          localStorage.setItem('mk_refresh_token', data.refreshToken);
        }

        originalRequest.headers.Authorization = `Bearer ${newAccessToken}`;
        processQueue(null, newAccessToken);
=======
      if (isRefreshing) {
        return new Promise((resolve, reject) => {
          failedQueue.push({ resolve, reject });
        }).then((token) => {
          originalRequest.headers.Authorization = `Bearer ${token}`;
          return apiClient(originalRequest);
        });
      }

      originalRequest._retry = true;
      isRefreshing = true;

      try {
        const { data } = await axios.post(`${API_CONFIG.API_BASE_URL}/auth/refresh`, { refreshToken });
        localStorage.setItem('mk_auth_token', data.accessToken);
        localStorage.setItem('mk_refresh_token', data.refreshToken);
        processQueue(null, data.accessToken);
        originalRequest.headers.Authorization = `Bearer ${data.accessToken}`;
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
        return apiClient(originalRequest);
      } catch (refreshError) {
        processQueue(refreshError, null);
        localStorage.removeItem('mk_auth_token');
        localStorage.removeItem('mk_refresh_token');
        localStorage.removeItem('mk_user');
        window.location.reload();
        return Promise.reject(refreshError);
      } finally {
        isRefreshing = false;
      }
    }

    console.error('API Error:', error.response?.data || error.message);
    return Promise.reject(error);
  }
);

<<<<<<< HEAD
export { apiClient };

export const apiService = {
  async getAll<T>(endpoint: string, params?: Record<string, any>): Promise<T[]> {
    const response = await apiClient.get(endpoint, { params });
    const body = response.data;
    // Support paginated responses: { data: [...], pagination: {...} }
    return Array.isArray(body) ? body : body.data;
=======
export interface PaginatedResult<T> {
  data: T[];
  pagination: { page: number; pageSize: number; total: number; totalPages: number };
}

export const apiService = {
  async getAll<T>(endpoint: string, params?: { page?: number; pageSize?: number; search?: string }): Promise<T[]> {
    const response = await apiClient.get(endpoint, { params });
    if (response.data && Array.isArray(response.data.data)) {
      return response.data.data;
    }
    return response.data;
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
  },

  async getPaginated<T>(endpoint: string, params?: { page?: number; pageSize?: number; search?: string }): Promise<PaginatedResult<T>> {
    const response = await apiClient.get(endpoint, { params });
    if (response.data && Array.isArray(response.data.data) && response.data.pagination) {
      return response.data;
    }
    // Fallback for non-paginated endpoints
    const arr = Array.isArray(response.data) ? response.data : [];
    return { data: arr, pagination: { page: 1, pageSize: arr.length, total: arr.length, totalPages: 1 } };
  },

  async getById<T>(endpoint: string, id: string): Promise<T> {
    const response = await apiClient.get(`${endpoint}/${id}`);
    return response.data;
  },

  async create<T>(endpoint: string, data: any): Promise<T> {
    const response = await apiClient.post(endpoint, data);
    return response.data;
  },

  async update<T>(endpoint: string, id: string, data: any): Promise<T> {
    const response = await apiClient.put(`${endpoint}/${id}`, data);
    return response.data;
  },

  async delete(endpoint: string, id: string): Promise<void> {
    await apiClient.delete(`${endpoint}/${id}`);
  },

  async upload(endpoint: string, formData: FormData): Promise<any> {
    const response = await apiClient.post(endpoint, formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return response.data;
  },
};

export default apiService;
