<<<<<<< HEAD
import React, { useState, useEffect } from 'react';
import { Home, MapPin, Building2, Boxes, Tag, Package, DollarSign, Users, CreditCard, ShoppingCart, AlertCircle, Bell, Edit2, Trash2, Plus, X, LogOut, Ticket, UserCog, Warehouse, ArrowUpDown, TrendingDown, PackageCheck, PackageX, Search, RefreshCw, Eye, ChevronRight, Clock, Upload, Image } from 'lucide-react';
=======
import React, { useState, useEffect, useRef } from 'react';
import { Home, MapPin, Building2, Boxes, Tag, Package, DollarSign, Users, CreditCard, ShoppingCart, AlertCircle, Bell, Edit2, Trash2, Plus, X, LogOut, Search, Ticket } from 'lucide-react';
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
import LoginPage from './auth/LoginPage';
import { zoneService } from './services/zone.service';
import { vendorService } from './services/vendor.service';
import { categoryService } from './services/category.service';
import { brandService } from './services/brand.service';
import { productService } from './services/product.service';
import { dealerService } from './services/dealer.service';
import { orderService, OrderDetail, OrderLineItem, StatusHistoryEntry } from './services/order.service';
import { buyerService } from './services/buyer.service';
<<<<<<< HEAD
import { Zone, Vendor, Category, Brand, Product, Order, Dealer, Buyer, Coupon, AdminUser } from './types';
import { couponService } from './services/coupon.service';
import { adminUserService } from './services/adminUser.service';
import { inventoryService, StockItem, InventorySummary, InventoryTransaction } from './services/inventory.service';
import { dashboardService, DashboardStats, OrdersByStatus, RevenueByMonth, TopProduct, RecentOrder } from './services/dashboard.service';
import { uploadService } from './services/upload.service';
import { INDIAN_STATES } from './constants/indianStates';
=======
import { couponService, Coupon } from './services/coupon.service';
import { Zone, Vendor, Category, Brand, Product, Order, Dealer, Buyer } from './types';
import { API_CONFIG } from './config/api.config';
import apiService from './services/api.service';
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
// API_CONFIG imported via services

// ============================================================================
// TYPES (extra interfaces not in types/index.ts)
// ============================================================================

interface AuthUser {
  email: string;
  firstName: string;
  lastName: string;
  roles: string[];
}

// ============================================================================
// MAIN APP WITH AUTH GATING
// ============================================================================
export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [user, setUser] = useState<AuthUser | null>(null);
  const [currentModule, setCurrentModule] = useState('dashboard');
  const [sidebarOpen] = useState(true);

  // Check for existing auth on mount
  useEffect(() => {
    const token = localStorage.getItem('mk_auth_token');
    const userJson = localStorage.getItem('mk_user');

    if (token && userJson) {
      try {
        const userData = JSON.parse(userJson);
        setUser(userData);
        setIsAuthenticated(true);
      } catch {
        localStorage.removeItem('mk_auth_token');
        localStorage.removeItem('mk_refresh_token');
        localStorage.removeItem('mk_user');
      }
    }
    setIsLoading(false);
  }, []);

<<<<<<< HEAD
  const handleLogin = (token: string, userData: AuthUser, refreshToken?: string) => {
=======
  const handleLogin = (token: string, refreshToken: string, userData: AuthUser) => {
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
    localStorage.setItem('mk_auth_token', token);
    localStorage.setItem('mk_refresh_token', refreshToken);
    localStorage.setItem('mk_user', JSON.stringify(userData));
    if (refreshToken) {
      localStorage.setItem('mk_refresh_token', refreshToken);
    }
    setUser(userData);
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    localStorage.removeItem('mk_auth_token');
    localStorage.removeItem('mk_refresh_token');
    localStorage.removeItem('mk_user');
    setUser(null);
    setIsAuthenticated(false);
    setCurrentModule('dashboard');
  };

  // Loading state
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-mk-red border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-600 font-semibold">Loading Material King...</p>
        </div>
      </div>
    );
  }

  // Show login page if not authenticated
  if (!isAuthenticated) {
    return <LoginPage onLogin={handleLogin} />;
  }

  // Authenticated — show admin panel
  return (
    <div className="min-h-screen bg-gray-50">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700&display=swap');
        * { font-family: 'Montserrat', sans-serif; }
      `}</style>

      <Header user={user} onLogout={handleLogout} />

      <div className="flex pt-16">
        <Sidebar
          currentModule={currentModule}
          setCurrentModule={setCurrentModule}
          isOpen={sidebarOpen}
        />

        <main className={`flex-1 transition-all duration-300 ${sidebarOpen ? 'ml-64' : 'ml-0'}`}>
          <div className="p-6">
            <ModuleRenderer module={currentModule} />
          </div>
        </main>
      </div>
    </div>
  );
}

// ============================================================================
// HEADER (with user info + logout)
// ============================================================================
function Header({ user, onLogout }: { user: AuthUser | null; onLogout: () => void }) {
  return (
    <header className="fixed top-0 left-0 right-0 h-16 bg-white border-b-4 border-mk-red flex items-center justify-between px-6 z-50 shadow-sm">
      <div className="flex items-center gap-4">
        <img src="/logo.png" alt="Material King" className="w-12 h-12 rounded-full object-cover" />
        <div>
          <h1 className="text-xl font-bold text-mk-gray">MATERIAL KING</h1>
          <p className="text-xs text-gray-500">Admin Portal</p>
        </div>
      </div>

      <div className="flex items-center gap-4">
        <div className="text-xs px-3 py-1 rounded-full bg-green-100 text-green-700">
          <span className="font-semibold">Live API</span>
        </div>
        <button className="relative p-2 hover:bg-gray-100 rounded-lg">
          <Bell className="w-5 h-5 text-gray-600" />
        </button>
        <div className="text-sm text-right">
          <p className="font-semibold text-gray-700">{user?.firstName} {user?.lastName}</p>
          <p className="text-xs text-gray-500">{user?.email}</p>
        </div>
        <button
          onClick={onLogout}
          className="flex items-center gap-2 px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 font-semibold text-sm"
        >
          <LogOut className="w-4 h-4" />
          Logout
        </button>
      </div>
    </header>
  );
}

// ============================================================================
// SIDEBAR
// ============================================================================
function Sidebar({ currentModule, setCurrentModule, isOpen }: any) {
  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: Home },
    { id: 'zones', label: 'Zones', icon: MapPin },
    { id: 'vendors', label: 'Vendors', icon: Building2 },
    { id: 'categories', label: 'Categories', icon: Boxes },
    { id: 'brands', label: 'Brands', icon: Tag },
    { id: 'products', label: 'Products', icon: Package },
    { id: 'dealers', label: 'Dealers', icon: Users },
    { id: 'buyers', label: 'Buyers', icon: CreditCard },
    { id: 'orders', label: 'Orders', icon: ShoppingCart },
<<<<<<< HEAD
    { id: 'inventory', label: 'Inventory', icon: Warehouse },
    { id: 'coupons', label: 'Coupons', icon: Ticket },
    { id: 'admin-users', label: 'Admin Users', icon: UserCog },
=======
    { id: 'coupons', label: 'Coupons', icon: Ticket },
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
  ];

  return (
    <aside className={`fixed left-0 top-16 h-[calc(100vh-4rem)] bg-white border-r transition-all duration-300 z-40 overflow-y-auto ${isOpen ? 'w-64' : 'w-0'}`}>
      <nav className="p-4">
        {menuItems.map(item => (
          <button
            key={item.id}
            onClick={() => setCurrentModule(item.id)}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg mb-1 transition ${
              currentModule === item.id
                ? 'bg-mk-red text-white font-bold'
                : 'text-gray-700 hover:bg-gray-100'
            }`}
          >
            <item.icon className="w-5 h-5" />
            <span className="text-sm">{item.label}</span>
          </button>
        ))}
      </nav>
    </aside>
  );
}

// ============================================================================
// MODULE RENDERER
// ============================================================================
function ModuleRenderer({ module }: { module: string }) {
<<<<<<< HEAD
  const modules: Record<string, JSX.Element> = {
    dashboard: <DashboardModule />,
    zones: <ZonesModule />,
    vendors: <VendorsModule />,
    categories: <CategoriesModule />,
    brands: <BrandsModule />,
    products: <ProductsModule />,
    dealers: <DealersModule />,
    buyers: <BuyersModule />,
    orders: <OrdersModule />,
    inventory: <InventoryModule />,
    coupons: <CouponsModule />,
    'admin-users': <AdminUsersModule />,
  };

  return modules[module] || <DashboardModule />;
=======
  switch (module) {
    case 'zones': return <ZonesModule />;
    case 'vendors': return <VendorsModule />;
    case 'categories': return <CategoriesModule />;
    case 'brands': return <BrandsModule />;
    case 'products': return <ProductsModule />;
    case 'dealers': return <DealersModule />;
    case 'buyers': return <BuyersModule />;
    case 'orders': return <OrdersModule />;
    case 'coupons': return <CouponsModule />;
    default: return <DashboardModule />;
  }
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
}

// ============================================================================
// DASHBOARD MODULE — REAL DATA
// ============================================================================
function DashboardModule() {
<<<<<<< HEAD
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [ordersByStatus, setOrdersByStatus] = useState<OrdersByStatus[]>([]);
  const [revenueByMonth, setRevenueByMonth] = useState<RevenueByMonth[]>([]);
  const [topProducts, setTopProducts] = useState<TopProduct[]>([]);
  const [recentOrders, setRecentOrders] = useState<RecentOrder[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const [s, obs, rbm, tp, ro] = await Promise.all([
          dashboardService.getStats(),
          dashboardService.getOrdersByStatus(),
          dashboardService.getRevenueByMonth(),
          dashboardService.getTopProducts(),
          dashboardService.getRecentOrders(),
        ]);
        setStats(s);
        setOrdersByStatus(obs);
        setRevenueByMonth(rbm);
        setTopProducts(tp);
        setRecentOrders(ro);
      } catch (err) {
        console.error('Dashboard load error:', err);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  if (loading) return <LoadingSpinner />;

  const formatCurrency = (val: string | number) => {
    const num = Number(val);
    if (num >= 10000000) return `₹${(num / 10000000).toFixed(2)} Cr`;
    if (num >= 100000) return `₹${(num / 100000).toFixed(2)} L`;
    return `₹${num.toLocaleString()}`;
  };

  const statCards = stats ? [
    { label: 'Total Orders', value: Number(stats.total_orders).toLocaleString(), icon: ShoppingCart, color: 'bg-blue-500' },
    { label: 'Pending Orders', value: Number(stats.pending_orders).toLocaleString(), icon: AlertCircle, color: 'bg-yellow-500' },
    { label: 'Delivered', value: Number(stats.delivered_orders).toLocaleString(), icon: Package, color: 'bg-green-500' },
    { label: 'Total Revenue', value: formatCurrency(stats.total_revenue), icon: DollarSign, color: 'bg-purple-500' },
    { label: 'Active Products', value: Number(stats.total_products).toLocaleString(), icon: Boxes, color: 'bg-indigo-500' },
    { label: 'Out of Stock', value: Number(stats.out_of_stock_products).toLocaleString(), icon: PackageX, color: 'bg-red-500' },
    { label: 'Total Buyers', value: Number(stats.total_buyers).toLocaleString(), icon: CreditCard, color: 'bg-cyan-500' },
    { label: 'Active Vendors', value: Number(stats.total_vendors).toLocaleString(), icon: Building2, color: 'bg-teal-500' },
  ] : [];

  const statusColors: Record<string, string> = {
    pending: 'bg-yellow-100 text-yellow-800',
    pending_dealer_approval: 'bg-orange-100 text-orange-800',
    confirmed: 'bg-blue-100 text-blue-800',
    processing: 'bg-indigo-100 text-indigo-800',
    shipped: 'bg-purple-100 text-purple-800',
    delivered: 'bg-green-100 text-green-800',
    cancelled: 'bg-red-100 text-red-800',
  };

  const maxRevenue = revenueByMonth.length > 0 ? Math.max(...revenueByMonth.map(r => Number(r.revenue))) : 1;
  const maxProductRevenue = topProducts.length > 0 ? Math.max(...topProducts.map(p => Number(p.revenue))) : 1;
=======
  const [stats, setStats] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const res = await fetch(`${API_CONFIG.API_BASE_URL.replace('/api', '')}/api/stats`);
        setStats(await res.json());
      } catch { /* ignore */ }
      finally { setLoading(false); }
    })();
  }, []);

  const formatCurrency = (v: number) => {
    if (v >= 10000000) return `₹${(v / 10000000).toFixed(1)} Cr`;
    if (v >= 100000) return `₹${(v / 100000).toFixed(1)} L`;
    if (v >= 1000) return `₹${(v / 1000).toFixed(1)} K`;
    return `₹${v}`;
  };

  const cards = stats ? [
    { label: 'Total Orders', value: stats.orders.toLocaleString(), icon: ShoppingCart, color: 'bg-blue-500' },
    { label: 'Active Vendors', value: stats.vendors.toLocaleString(), icon: Building2, color: 'bg-green-500' },
    { label: 'Total GMV', value: formatCurrency(stats.gmv), icon: DollarSign, color: 'bg-purple-500' },
    { label: 'Pending Orders', value: stats.pending_orders.toLocaleString(), icon: AlertCircle, color: 'bg-red-500' },
    { label: 'Products', value: stats.products.toLocaleString(), icon: Package, color: 'bg-indigo-500' },
    { label: 'Dealers', value: stats.dealers.toLocaleString(), icon: Users, color: 'bg-teal-500' },
    { label: 'Buyers', value: stats.buyers.toLocaleString(), icon: CreditCard, color: 'bg-orange-500' },
    { label: 'Categories', value: stats.categories.toLocaleString(), icon: Boxes, color: 'bg-cyan-500' },
  ] : [];

  if (loading) return <LoadingSpinner />;
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611

  return (
    <div>
      <h1 className="text-3xl font-bold text-mk-gray mb-6">Dashboard</h1>
<<<<<<< HEAD

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        {statCards.map((stat, idx) => (
          <div key={idx} className="bg-white rounded-xl p-5 shadow-md border-l-4 border-mk-red">
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs text-gray-500 font-bold uppercase">{stat.label}</span>
              <div className={`p-2 rounded-lg ${stat.color} bg-opacity-10`}>
                <stat.icon className={`w-5 h-5 ${stat.color.replace('bg-', 'text-')}`} />
=======
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {cards.map((stat, idx) => (
          <div key={idx} className="bg-white rounded-xl p-6 shadow-md border-l-4 border-mk-red">
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm text-gray-500 font-bold uppercase">{stat.label}</span>
              <div className={`p-3 rounded-lg ${stat.color} bg-opacity-10`}>
                <stat.icon className={`w-6 h-6 ${stat.color.replace('bg-', 'text-')}`} />
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
              </div>
            </div>
            <p className="text-2xl font-bold text-mk-gray">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Revenue by Month — Bar Chart */}
        <div className="bg-white rounded-xl shadow-md p-6">
          <h2 className="text-lg font-bold text-mk-gray mb-4">Revenue by Month</h2>
          {revenueByMonth.length === 0 ? (
            <p className="text-gray-400 text-center py-8">No revenue data yet.</p>
          ) : (
            <div className="space-y-2">
              {revenueByMonth.map((r, i) => (
                <div key={i} className="flex items-center gap-3">
                  <span className="text-xs font-bold text-gray-500 w-20 shrink-0">{r.month}</span>
                  <div className="flex-1 bg-gray-100 rounded-full h-6 overflow-hidden">
                    <div
                      className="bg-gradient-to-r from-mk-red to-red-400 h-full rounded-full flex items-center justify-end pr-2"
                      style={{ width: `${Math.max((Number(r.revenue) / maxRevenue) * 100, 5)}%` }}
                    >
                      <span className="text-[10px] font-bold text-white whitespace-nowrap">{formatCurrency(r.revenue)}</span>
                    </div>
                  </div>
                  <span className="text-xs text-gray-400 w-16 text-right">{r.orders} orders</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Orders by Status */}
        <div className="bg-white rounded-xl shadow-md p-6">
          <h2 className="text-lg font-bold text-mk-gray mb-4">Orders by Status</h2>
          {ordersByStatus.length === 0 ? (
            <p className="text-gray-400 text-center py-8">No orders yet.</p>
          ) : (
            <div className="space-y-3">
              {ordersByStatus.map((item, i) => {
                const total = ordersByStatus.reduce((sum, o) => sum + o.value, 0);
                const pct = total > 0 ? ((item.value / total) * 100).toFixed(1) : '0';
                return (
                  <div key={i} className="flex items-center gap-3">
                    <span className={`px-3 py-1 rounded-full text-xs font-bold w-44 text-center ${statusColors[item.name] || 'bg-gray-100 text-gray-700'}`}>
                      {item.name.replace(/_/g, ' ').toUpperCase()}
                    </span>
                    <div className="flex-1 bg-gray-100 rounded-full h-5 overflow-hidden">
                      <div className="bg-mk-red h-full rounded-full" style={{ width: `${Math.max(Number(pct), 2)}%` }} />
                    </div>
                    <span className="text-sm font-bold text-gray-700 w-12 text-right">{item.value}</span>
                    <span className="text-xs text-gray-400 w-12 text-right">{pct}%</span>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Products */}
        <div className="bg-white rounded-xl shadow-md p-6">
          <h2 className="text-lg font-bold text-mk-gray mb-4">Top 10 Products by Revenue</h2>
          {topProducts.length === 0 ? (
            <p className="text-gray-400 text-center py-8">No product sales data yet.</p>
          ) : (
            <div className="space-y-3">
              {topProducts.map((p, i) => (
                <div key={i} className="flex items-center gap-3">
                  <span className="text-xs font-bold bg-mk-red text-white w-6 h-6 rounded-full flex items-center justify-center shrink-0">{i + 1}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-bold truncate">{p.name}</p>
                    <div className="bg-gray-100 rounded-full h-3 mt-1 overflow-hidden">
                      <div className="bg-gradient-to-r from-green-500 to-emerald-400 h-full rounded-full" style={{ width: `${(Number(p.revenue) / maxProductRevenue) * 100}%` }} />
                    </div>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="text-sm font-bold">{formatCurrency(p.revenue)}</p>
                    <p className="text-xs text-gray-400">{p.units_sold} units</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Recent Orders */}
        <div className="bg-white rounded-xl shadow-md p-6">
          <h2 className="text-lg font-bold text-mk-gray mb-4">Recent Orders</h2>
          {recentOrders.length === 0 ? (
            <p className="text-gray-400 text-center py-8">No orders yet.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50"><tr>
                  <th className="px-3 py-2 text-left text-xs font-bold text-gray-600">Order #</th>
                  <th className="px-3 py-2 text-left text-xs font-bold text-gray-600">Buyer</th>
                  <th className="px-3 py-2 text-center text-xs font-bold text-gray-600">Status</th>
                  <th className="px-3 py-2 text-right text-xs font-bold text-gray-600">Amount</th>
                </tr></thead>
                <tbody>{recentOrders.map(order => (
                  <tr key={order.id} className="border-t hover:bg-gray-50">
                    <td className="px-3 py-2 text-sm font-bold">{order.order_number}</td>
                    <td className="px-3 py-2 text-sm text-gray-600 truncate max-w-[150px]">{order.buyer_company || '-'}</td>
                    <td className="px-3 py-2 text-center">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${statusColors[order.status] || 'bg-gray-100 text-gray-700'}`}>
                        {order.status.replace(/_/g, ' ').toUpperCase()}
                      </span>
                    </td>
                    <td className="px-3 py-2 text-sm font-bold text-right">₹{Number(order.total_amount).toLocaleString()}</td>
                  </tr>
                ))}</tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// LOADING SPINNER
// ============================================================================
function LoadingSpinner() {
  return (
    <div className="flex items-center justify-center py-20">
      <div className="w-10 h-10 border-4 border-mk-red border-t-transparent rounded-full animate-spin"></div>
    </div>
  );
}

// ============================================================================
// PAGINATION COMPONENT
// ============================================================================
function Pagination({ page, totalPages, total, pageSize, onPageChange }: {
  page: number; totalPages: number; total: number; pageSize: number;
  onPageChange: (p: number) => void;
}) {
  if (totalPages <= 1) return null;
  const start = (page - 1) * pageSize + 1;
  const end = Math.min(page * pageSize, total);

  return (
    <div className="flex items-center justify-between mt-4 pt-4 border-t">
      <p className="text-sm text-gray-500">Showing {start}–{end} of {total}</p>
      <div className="flex items-center gap-1">
        <button onClick={() => onPageChange(1)} disabled={page <= 1}
          className="px-2 py-1 text-xs rounded border hover:bg-gray-50 disabled:opacity-30 disabled:cursor-not-allowed">First</button>
        <button onClick={() => onPageChange(page - 1)} disabled={page <= 1}
          className="px-3 py-1 text-sm rounded border hover:bg-gray-50 disabled:opacity-30 disabled:cursor-not-allowed">Prev</button>
        {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
          let p: number;
          if (totalPages <= 5) p = i + 1;
          else if (page <= 3) p = i + 1;
          else if (page >= totalPages - 2) p = totalPages - 4 + i;
          else p = page - 2 + i;
          return (
            <button key={p} onClick={() => onPageChange(p)}
              className={`px-3 py-1 text-sm rounded border ${p === page ? 'bg-mk-red text-white border-mk-red font-bold' : 'hover:bg-gray-50'}`}>{p}</button>
          );
        })}
        <button onClick={() => onPageChange(page + 1)} disabled={page >= totalPages}
          className="px-3 py-1 text-sm rounded border hover:bg-gray-50 disabled:opacity-30 disabled:cursor-not-allowed">Next</button>
        <button onClick={() => onPageChange(totalPages)} disabled={page >= totalPages}
          className="px-2 py-1 text-xs rounded border hover:bg-gray-50 disabled:opacity-30 disabled:cursor-not-allowed">Last</button>
      </div>
    </div>
  );
}

// ============================================================================
// SEARCH BAR COMPONENT
// ============================================================================
function SearchBar({ value, onChange, placeholder }: { value: string; onChange: (v: string) => void; placeholder?: string }) {
  return (
    <div className="relative">
      <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
      <input type="text" value={value} onChange={e => onChange(e.target.value)}
        placeholder={placeholder || 'Search...'}
        className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-mk-red focus:border-mk-red outline-none w-64" />
    </div>
  );
}

// ============================================================================
// ZONES MODULE - API-BACKED CRUD
// ============================================================================
function ZonesModule() {
  const [zones, setZones] = useState<Zone[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingZone, setEditingZone] = useState<Zone | null>(null);
  const [formData, setFormData] = useState({ code: '', name: '', description: '', is_active: true as boolean });
  const [saving, setSaving] = useState(false);
<<<<<<< HEAD
  const [searchTerm, setSearchTerm] = useState('');
=======
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [pagination, setPagination] = useState({ page: 1, pageSize: 20, total: 0, totalPages: 1 });
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611

  const loadData = async (p = page, s = search) => {
    try {
      const result = await zoneService.getPaginated(p, 20, s);
      setZones(Array.isArray(result.data) ? result.data : []);
      setPagination(result.pagination);
    } catch (err) { console.error('Failed to load zones:', err); }
    finally { setLoading(false); }
  };

  useEffect(() => { loadData(); }, [page]);
  useEffect(() => { const t = setTimeout(() => { setPage(1); loadData(1, search); }, 300); return () => clearTimeout(t); }, [search]);

  const handlePageChange = (p: number) => { setPage(p); };

  const handleAdd = () => { setEditingZone(null); setFormData({ code: '', name: '', description: '', is_active: true }); setShowModal(true); };
  const handleEdit = (zone: Zone) => { setEditingZone(zone); setFormData({ code: zone.code, name: zone.name, description: zone.description || '', is_active: zone.is_active !== false }); setShowModal(true); };

  const handleSave = async () => {
    setSaving(true);
    try {
      if (editingZone) { await zoneService.update(editingZone.id, formData); }
      else { await zoneService.create(formData); }
      await loadData(); setShowModal(false);
    } catch (err) { console.error('Save zone error:', err); alert('Failed to save zone.'); }
    finally { setSaving(false); }
  };

  const handleDelete = async (id: string) => {
    if (confirm('Delete this zone?')) {
      try { await zoneService.delete(id); await loadData(); }
      catch (err) { console.error('Delete zone error:', err); alert('Failed to delete zone.'); }
    }
  };

  if (loading) return <LoadingSpinner />;

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-mk-gray">Zones</h1>
        <div className="flex items-center gap-3">
          <SearchBar value={search} onChange={setSearch} placeholder="Search zones..." />
          <button onClick={handleAdd} className="btn-primary flex items-center gap-2"><Plus className="w-5 h-5" /> Add Zone</button>
        </div>
      </div>
      <div className="bg-white rounded-xl shadow-md p-6">
        <div className="flex items-center gap-3 mb-4"><div className="relative flex-1 max-w-md"><Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" /><input type="text" placeholder="Search zones..." className="input-field pl-10" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} /></div></div>
        {(() => { const filtered = zones.filter(z => !searchTerm || z.name.toLowerCase().includes(searchTerm.toLowerCase()) || z.code.toLowerCase().includes(searchTerm.toLowerCase())); return filtered.length === 0 ? <p className="text-gray-500 text-center py-8">No zones found.</p> : (
          <table className="w-full">
            <thead className="bg-gray-50"><tr>
              <th className="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase">Code</th>
              <th className="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase">Name</th>
              <th className="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase">Description</th>
              <th className="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase">Status</th>
              <th className="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase">Actions</th>
            </tr></thead>
            <tbody>{filtered.map(zone => (
              <tr key={zone.id} className="border-t hover:bg-gray-50">
                <td className="px-6 py-4 font-bold">{zone.code}</td>
                <td className="px-6 py-4">{zone.name}</td>
                <td className="px-6 py-4 text-sm text-gray-500">{zone.description || '-'}</td>
                <td className="px-6 py-4"><span className={`px-3 py-1 rounded-full text-xs font-bold ${zone.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>{zone.is_active ? 'Active' : 'Inactive'}</span></td>
                <td className="px-6 py-4"><div className="flex gap-2">
                  <button onClick={() => handleEdit(zone)} className="p-2 text-blue-600 hover:bg-blue-50 rounded"><Edit2 className="w-4 h-4" /></button>
                  <button onClick={() => handleDelete(zone.id)} className="p-2 text-red-600 hover:bg-red-50 rounded"><Trash2 className="w-4 h-4" /></button>
                </div></td>
              </tr>
            ))}</tbody>
          </table>
<<<<<<< HEAD
        ); })()}
=======
        )}
        <Pagination page={pagination.page} totalPages={pagination.totalPages} total={pagination.total} pageSize={pagination.pageSize} onPageChange={handlePageChange} />
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
      </div>
      {showModal && (
        <Modal title={editingZone ? 'Edit Zone' : 'Add Zone'} onClose={() => setShowModal(false)}>
          <div className="space-y-4">
            <div><label className="block text-sm font-bold mb-2">Zone Code</label><input type="text" className="input-field" value={formData.code} onChange={e => setFormData({ ...formData, code: e.target.value })} placeholder="ZONE-MUM-N" /></div>
            <div><label className="block text-sm font-bold mb-2">Zone Name</label><input type="text" className="input-field" value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} placeholder="Mumbai North" /></div>
            <div><label className="block text-sm font-bold mb-2">Description</label><input type="text" className="input-field" value={formData.description} onChange={e => setFormData({ ...formData, description: e.target.value })} placeholder="Covers Mumbai North region" /></div>
            <div><label className="flex items-center gap-3 cursor-pointer"><input type="checkbox" checked={formData.is_active} onChange={e => setFormData({ ...formData, is_active: e.target.checked })} className="w-5 h-5 accent-mk-red" /><span className="text-sm font-bold">Active</span></label></div>
          </div>
          <div className="flex gap-3 mt-6">
            <button onClick={() => setShowModal(false)} className="flex-1 px-4 py-2 border-2 border-gray-300 rounded-lg hover:bg-gray-100 font-bold">Cancel</button>
            <button onClick={handleSave} disabled={saving} className="flex-1 btn-primary disabled:opacity-50">{saving ? 'Saving...' : 'Save Zone'}</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ============================================================================
// VENDORS MODULE - API-BACKED CRUD
// ============================================================================
function VendorsModule() {
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [zones, setZones] = useState<Zone[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingVendor, setEditingVendor] = useState<Vendor | null>(null);
<<<<<<< HEAD
  const [formData, setFormData] = useState({ company_name: '', contact_name: '', email: '', phone: '', gstin: '', address: '', city: '', state: '', pincode: '', zone_id: '', is_active: true as boolean, is_verified: false as boolean });
  const [saving, setSaving] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const loadData = async () => {
    try {
      const [vendorData, zoneData] = await Promise.all([vendorService.getAll(), zoneService.getAll()]);
      setVendors(vendorData); setZones(zoneData);
    }
    catch (err) { console.error('Failed to load vendors:', err); }
=======
  const [formData, setFormData] = useState({ company_name: '', contact_name: '', email: '', phone: '', gstin: '', address: '', city: '', state: '', pincode: '', zone_id: '' });
  const [saving, setSaving] = useState(false);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [pagination, setPagination] = useState({ page: 1, pageSize: 20, total: 0, totalPages: 1 });

  const loadData = async (p = page, s = search) => {
    try {
      const [result, zoneData] = await Promise.all([vendorService.getPaginated(p, 20, s), zoneService.getAll()]);
      setVendors(Array.isArray(result.data) ? result.data : []);
      setPagination(result.pagination);
      setZones(Array.isArray(zoneData) ? zoneData : []);
    } catch (err) { console.error('Failed to load vendors:', err); }
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
    finally { setLoading(false); }
  };

  useEffect(() => { loadData(); }, [page]);
  useEffect(() => { const t = setTimeout(() => { setPage(1); loadData(1, search); }, 300); return () => clearTimeout(t); }, [search]);

<<<<<<< HEAD
  const handleAdd = () => { setEditingVendor(null); setFormData({ company_name: '', contact_name: '', email: '', phone: '', gstin: '', address: '', city: '', state: '', pincode: '', zone_id: '', is_active: true, is_verified: false }); setShowModal(true); };
  const handleEdit = (vendor: Vendor) => { setEditingVendor(vendor); setFormData({ company_name: vendor.company_name, contact_name: vendor.contact_name || '', email: vendor.email || '', phone: vendor.phone || '', gstin: vendor.gstin || '', address: vendor.address || '', city: vendor.city || '', state: vendor.state || '', pincode: vendor.pincode || '', zone_id: (vendor as any).zone_id ? String((vendor as any).zone_id) : '', is_active: vendor.is_active !== false, is_verified: vendor.is_verified === true }); setShowModal(true); };
=======
  const handlePageChange = (p: number) => { setPage(p); };

  const handleAdd = () => { setEditingVendor(null); setFormData({ company_name: '', contact_name: '', email: '', phone: '', gstin: '', address: '', city: '', state: '', pincode: '', zone_id: '' }); setShowModal(true); };
  const handleEdit = (vendor: Vendor) => { setEditingVendor(vendor); setFormData({ company_name: vendor.company_name, contact_name: vendor.contact_name || '', email: vendor.email || '', phone: vendor.phone || '', gstin: vendor.gstin || '', address: (vendor as any).address || '', city: vendor.city || '', state: vendor.state || '', pincode: (vendor as any).pincode || '', zone_id: (vendor as any).zone_id ? String((vendor as any).zone_id) : '' }); setShowModal(true); };
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611

  const handleSave = async () => {
    setSaving(true);
    try {
      const payload = { ...formData, zone_id: formData.zone_id ? Number(formData.zone_id) : null } as any;
      if (editingVendor) { await vendorService.update(editingVendor.id, payload); }
      else { await vendorService.create(payload); }
      await loadData(); setShowModal(false);
    } catch (err) { console.error('Save vendor error:', err); alert('Failed to save vendor.'); }
    finally { setSaving(false); }
  };

  const handleDelete = async (id: string) => {
    if (confirm('Delete this vendor?')) {
      try { await vendorService.delete(id); await loadData(); }
      catch (err) { console.error('Delete vendor error:', err); alert('Failed to delete vendor.'); }
    }
  };

  if (loading) return <LoadingSpinner />;

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-mk-gray">Vendor Management</h1>
        <div className="flex items-center gap-3">
          <SearchBar value={search} onChange={setSearch} placeholder="Search vendors..." />
          <button onClick={handleAdd} className="btn-primary flex items-center gap-2"><Plus className="w-5 h-5" /> Add Vendor</button>
        </div>
      </div>
      <div className="bg-white rounded-xl shadow-md p-6">
        <div className="flex items-center gap-3 mb-4"><div className="relative flex-1 max-w-md"><Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" /><input type="text" placeholder="Search by company, contact, or GSTIN..." className="input-field pl-10" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} /></div></div>
        {(() => { const filtered = vendors.filter(v => !searchTerm || v.company_name.toLowerCase().includes(searchTerm.toLowerCase()) || (v.contact_name && v.contact_name.toLowerCase().includes(searchTerm.toLowerCase())) || (v.gstin && v.gstin.toLowerCase().includes(searchTerm.toLowerCase()))); return filtered.length === 0 ? <p className="text-gray-500 text-center py-8">No vendors found.</p> : (
          <table className="w-full">
            <thead className="bg-gray-50"><tr>
              <th className="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase">Company</th>
              <th className="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase">Contact</th>
              <th className="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase">GSTIN</th>
              <th className="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase">City</th>
              <th className="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase">Zone</th>
              <th className="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase">Status</th>
              <th className="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase">Actions</th>
            </tr></thead>
            <tbody>{filtered.map(vendor => (
              <tr key={vendor.id} className="border-t hover:bg-gray-50">
                <td className="px-6 py-4 font-bold">{vendor.company_name}</td>
                <td className="px-6 py-4 text-sm">{vendor.contact_name || '-'}<br/><span className="text-gray-400">{vendor.phone || ''}</span></td>
                <td className="px-6 py-4 font-mono text-sm">{vendor.gstin || '-'}</td>
                <td className="px-6 py-4 text-sm">{vendor.city || '-'}</td>
                <td className="px-6 py-4 text-sm">{(vendor as any).zone_name || '-'}</td>
                <td className="px-6 py-4"><span className={`px-3 py-1 rounded-full text-xs font-bold ${vendor.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>{vendor.is_active ? 'Active' : 'Inactive'}</span></td>
                <td className="px-6 py-4"><div className="flex gap-2">
                  <button onClick={() => handleEdit(vendor)} className="p-2 text-blue-600 hover:bg-blue-50 rounded"><Edit2 className="w-4 h-4" /></button>
                  <button onClick={() => handleDelete(vendor.id)} className="p-2 text-red-600 hover:bg-red-50 rounded"><Trash2 className="w-4 h-4" /></button>
                </div></td>
              </tr>
            ))}</tbody>
          </table>
<<<<<<< HEAD
        ); })()}
=======
        )}
        <Pagination page={pagination.page} totalPages={pagination.totalPages} total={pagination.total} pageSize={pagination.pageSize} onPageChange={handlePageChange} />
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
      </div>
      {showModal && (
        <Modal title={editingVendor ? 'Edit Vendor' : 'Add Vendor'} onClose={() => setShowModal(false)}>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div><label className="block text-sm font-bold mb-2">Company Name *</label><input type="text" className="input-field" value={formData.company_name} onChange={e => setFormData({ ...formData, company_name: e.target.value })} placeholder="ABC Distributors" /></div>
              <div><label className="block text-sm font-bold mb-2">Contact Name</label><input type="text" className="input-field" value={formData.contact_name} onChange={e => setFormData({ ...formData, contact_name: e.target.value })} placeholder="John Doe" /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><label className="block text-sm font-bold mb-2">Phone</label><input type="text" className="input-field" value={formData.phone} onChange={e => setFormData({ ...formData, phone: e.target.value })} placeholder="9876543210" /></div>
              <div><label className="block text-sm font-bold mb-2">Email</label><input type="email" className="input-field" value={formData.email} onChange={e => setFormData({ ...formData, email: e.target.value })} placeholder="john@abc.com" /></div>
            </div>
            <div><label className="block text-sm font-bold mb-2">GSTIN</label><input type="text" className="input-field" value={formData.gstin} onChange={e => setFormData({ ...formData, gstin: e.target.value })} placeholder="27AAACR5678C1Z9" /></div>
            <div><label className="block text-sm font-bold mb-2">Address</label><input type="text" className="input-field" value={formData.address} onChange={e => setFormData({ ...formData, address: e.target.value })} placeholder="Full address" /></div>
            <div className="grid grid-cols-3 gap-4">
              <div><label className="block text-sm font-bold mb-2">City</label><input type="text" className="input-field" value={formData.city} onChange={e => setFormData({ ...formData, city: e.target.value })} placeholder="Mumbai" /></div>
              <div><label className="block text-sm font-bold mb-2">State</label>
                <select className="input-field" value={formData.state} onChange={e => setFormData({ ...formData, state: e.target.value })}>
                  <option value="">Select State</option>
                  {INDIAN_STATES.map(s => <option key={s.code} value={s.code}>{s.name} ({s.code})</option>)}
                </select>
              </div>
              <div><label className="block text-sm font-bold mb-2">Pincode</label><input type="text" className="input-field" value={formData.pincode} onChange={e => setFormData({ ...formData, pincode: e.target.value })} placeholder="400001" /></div>
            </div>
            <div><label className="block text-sm font-bold mb-2">Zone</label>
              <select className="input-field" value={formData.zone_id} onChange={e => setFormData({ ...formData, zone_id: e.target.value })}>
                <option value="">Select Zone</option>
<<<<<<< HEAD
                {zones.filter(z => z.is_active).map(z => <option key={z.id} value={z.id}>{z.name} ({z.code})</option>)}
              </select>
            </div>
            <div className="flex gap-6">
              <label className="flex items-center gap-3 cursor-pointer"><input type="checkbox" checked={formData.is_active} onChange={e => setFormData({ ...formData, is_active: e.target.checked })} className="w-5 h-5 accent-mk-red" /><span className="text-sm font-bold">Active</span></label>
              <label className="flex items-center gap-3 cursor-pointer"><input type="checkbox" checked={formData.is_verified} onChange={e => setFormData({ ...formData, is_verified: e.target.checked })} className="w-5 h-5 accent-green-600" /><span className="text-sm font-bold">Verified</span></label>
            </div>
=======
                {zones.map(z => <option key={z.id} value={z.id}>{z.name} ({z.code})</option>)}
              </select>
            </div>
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
          </div>
          <div className="flex gap-3 mt-6">
            <button onClick={() => setShowModal(false)} className="flex-1 px-4 py-2 border-2 border-gray-300 rounded-lg hover:bg-gray-100 font-bold">Cancel</button>
            <button onClick={handleSave} disabled={saving} className="flex-1 btn-primary disabled:opacity-50">{saving ? 'Saving...' : 'Save Vendor'}</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ============================================================================
// CATEGORIES MODULE - API-BACKED CRUD
// ============================================================================
function CategoriesModule() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingItem, setEditingItem] = useState<Category | null>(null);
  const [formData, setFormData] = useState({ name: '', slug: '', is_active: true as boolean });
  const [saving, setSaving] = useState(false);
<<<<<<< HEAD
  const [searchTerm, setSearchTerm] = useState('');
=======
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState({ page: 1, pageSize: 20, total: 0, totalPages: 1 });
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611

  const [search, setSearch] = useState('');

  const loadData = async (p = page, s = search) => {
    try {
      const result = await categoryService.getPaginated(p, 20, s);
      setCategories(Array.isArray(result.data) ? result.data : []);
      setPagination(result.pagination);
    } catch (err) { console.error('Failed to load categories:', err); }
    finally { setLoading(false); }
  };

  useEffect(() => { loadData(); }, [page]);
  useEffect(() => { const t = setTimeout(() => { setPage(1); loadData(1, search); }, 300); return () => clearTimeout(t); }, [search]);

  const handlePageChange = (p: number) => { setPage(p); };

  const handleAdd = () => { setEditingItem(null); setFormData({ name: '', slug: '', is_active: true }); setShowModal(true); };
  const handleEdit = (item: Category) => { setEditingItem(item); setFormData({ name: item.name, slug: item.slug, is_active: item.is_active !== false }); setShowModal(true); };

  const handleSave = async () => {
    setSaving(true);
    try {
      if (editingItem) { await categoryService.update(editingItem.id, formData); }
      else { await categoryService.create(formData); }
      await loadData(); setShowModal(false);
    } catch (err) { console.error('Save category error:', err); alert('Failed to save category.'); }
    finally { setSaving(false); }
  };

  const handleDelete = async (id: string) => {
    if (confirm('Delete this category?')) {
      try { await categoryService.delete(id); await loadData(); }
      catch (err) { console.error('Delete category error:', err); alert('Failed to delete category.'); }
    }
  };

  if (loading) return <LoadingSpinner />;

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-mk-gray">Categories</h1>
        <div className="flex items-center gap-3">
          <SearchBar value={search} onChange={setSearch} placeholder="Search categories..." />
          <button onClick={handleAdd} className="btn-primary flex items-center gap-2"><Plus className="w-5 h-5" /> Add Category</button>
        </div>
      </div>
      <div className="bg-white rounded-xl shadow-md p-6">
        <div className="flex items-center gap-3 mb-4"><div className="relative flex-1 max-w-md"><Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" /><input type="text" placeholder="Search categories..." className="input-field pl-10" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} /></div></div>
        {(() => { const filtered = categories.filter(c => !searchTerm || c.name.toLowerCase().includes(searchTerm.toLowerCase()) || c.slug.toLowerCase().includes(searchTerm.toLowerCase())); return filtered.length === 0 ? <p className="text-gray-500 text-center py-8">No categories found.</p> : (
          <table className="w-full">
            <thead className="bg-gray-50"><tr>
              <th className="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase">Name</th>
              <th className="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase">Code</th>
              <th className="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase">Status</th>
              <th className="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase">Actions</th>
            </tr></thead>
            <tbody>{filtered.map(cat => (
              <tr key={cat.id} className="border-t hover:bg-gray-50">
                <td className="px-6 py-4 font-bold">{cat.name}</td>
                <td className="px-6 py-4 text-sm">{cat.slug}</td>
                <td className="px-6 py-4"><span className={`px-3 py-1 rounded-full text-xs font-bold ${cat.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>{cat.is_active ? 'Active' : 'Inactive'}</span></td>
                <td className="px-6 py-4"><div className="flex gap-2">
                  <button onClick={() => handleEdit(cat)} className="p-2 text-blue-600 hover:bg-blue-50 rounded"><Edit2 className="w-4 h-4" /></button>
                  <button onClick={() => handleDelete(cat.id)} className="p-2 text-red-600 hover:bg-red-50 rounded"><Trash2 className="w-4 h-4" /></button>
                </div></td>
              </tr>
            ))}</tbody>
          </table>
<<<<<<< HEAD
        ); })()}
=======
        )}
        <Pagination page={pagination.page} totalPages={pagination.totalPages} total={pagination.total} pageSize={pagination.pageSize} onPageChange={handlePageChange} />
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
      </div>
      {showModal && (
        <Modal title={editingItem ? 'Edit Category' : 'Add Category'} onClose={() => setShowModal(false)}>
          <div className="space-y-4">
            <div><label className="block text-sm font-bold mb-2">Category Name</label><input type="text" className="input-field" value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} placeholder="Plywood" /></div>
            <div><label className="block text-sm font-bold mb-2">Slug</label><input type="text" className="input-field" value={formData.slug} onChange={e => setFormData({ ...formData, slug: e.target.value })} placeholder="plywood (auto-generated if empty)" /></div>
            <div><label className="flex items-center gap-3 cursor-pointer"><input type="checkbox" checked={formData.is_active} onChange={e => setFormData({ ...formData, is_active: e.target.checked })} className="w-5 h-5 accent-mk-red" /><span className="text-sm font-bold">Active</span></label></div>
          </div>
          <div className="flex gap-3 mt-6">
            <button onClick={() => setShowModal(false)} className="flex-1 px-4 py-2 border-2 border-gray-300 rounded-lg hover:bg-gray-100 font-bold">Cancel</button>
            <button onClick={handleSave} disabled={saving} className="flex-1 btn-primary disabled:opacity-50">{saving ? 'Saving...' : 'Save Category'}</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ============================================================================
// BRANDS MODULE - API-BACKED CRUD
// ============================================================================
function BrandsModule() {
  const [brands, setBrands] = useState<Brand[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingItem, setEditingItem] = useState<Brand | null>(null);
  const [formData, setFormData] = useState({ name: '', slug: '', is_active: true as boolean });
  const [saving, setSaving] = useState(false);
<<<<<<< HEAD
  const [searchTerm, setSearchTerm] = useState('');
=======
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState({ page: 1, pageSize: 20, total: 0, totalPages: 1 });
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611

  const [search, setSearch] = useState('');

  const loadData = async (p = page, s = search) => {
    try {
      const result = await brandService.getPaginated(p, 20, s);
      setBrands(Array.isArray(result.data) ? result.data : []);
      setPagination(result.pagination);
    } catch (err) { console.error('Failed to load brands:', err); }
    finally { setLoading(false); }
  };

  useEffect(() => { loadData(); }, [page]);
  useEffect(() => { const t = setTimeout(() => { setPage(1); loadData(1, search); }, 300); return () => clearTimeout(t); }, [search]);

  const handlePageChange = (p: number) => { setPage(p); };

  const handleAdd = () => { setEditingItem(null); setFormData({ name: '', slug: '', is_active: true }); setShowModal(true); };
  const handleEdit = (item: Brand) => { setEditingItem(item); setFormData({ name: item.name, slug: item.slug, is_active: item.is_active !== false }); setShowModal(true); };

  const handleSave = async () => {
    setSaving(true);
    try {
      if (editingItem) { await brandService.update(editingItem.id, formData); }
      else { await brandService.create(formData); }
      await loadData(); setShowModal(false);
    } catch (err) { console.error('Save brand error:', err); alert('Failed to save brand.'); }
    finally { setSaving(false); }
  };

  const handleDelete = async (id: string) => {
    if (confirm('Delete this brand?')) {
      try { await brandService.delete(id); await loadData(); }
      catch (err) { console.error('Delete brand error:', err); alert('Failed to delete brand.'); }
    }
  };

  if (loading) return <LoadingSpinner />;

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-mk-gray">Brands</h1>
        <div className="flex items-center gap-3">
          <SearchBar value={search} onChange={setSearch} placeholder="Search brands..." />
          <button onClick={handleAdd} className="btn-primary flex items-center gap-2"><Plus className="w-5 h-5" /> Add Brand</button>
        </div>
      </div>
      <div className="bg-white rounded-xl shadow-md p-6">
        <div className="flex items-center gap-3 mb-4"><div className="relative flex-1 max-w-md"><Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" /><input type="text" placeholder="Search brands..." className="input-field pl-10" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} /></div></div>
        {(() => { const filtered = brands.filter(b => !searchTerm || b.name.toLowerCase().includes(searchTerm.toLowerCase()) || b.slug.toLowerCase().includes(searchTerm.toLowerCase())); return filtered.length === 0 ? <p className="text-gray-500 text-center py-8">No brands found.</p> : (
          <table className="w-full">
            <thead className="bg-gray-50"><tr>
              <th className="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase">Name</th>
              <th className="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase">Code</th>
              <th className="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase">Status</th>
              <th className="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase">Actions</th>
            </tr></thead>
            <tbody>{filtered.map(brand => (
              <tr key={brand.id} className="border-t hover:bg-gray-50">
                <td className="px-6 py-4 font-bold">{brand.name}</td>
                <td className="px-6 py-4 text-sm">{brand.slug}</td>
                <td className="px-6 py-4"><span className={`px-3 py-1 rounded-full text-xs font-bold ${brand.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>{brand.is_active ? 'Active' : 'Inactive'}</span></td>
                <td className="px-6 py-4"><div className="flex gap-2">
                  <button onClick={() => handleEdit(brand)} className="p-2 text-blue-600 hover:bg-blue-50 rounded"><Edit2 className="w-4 h-4" /></button>
                  <button onClick={() => handleDelete(brand.id)} className="p-2 text-red-600 hover:bg-red-50 rounded"><Trash2 className="w-4 h-4" /></button>
                </div></td>
              </tr>
            ))}</tbody>
          </table>
<<<<<<< HEAD
        ); })()}
=======
        )}
        <Pagination page={pagination.page} totalPages={pagination.totalPages} total={pagination.total} pageSize={pagination.pageSize} onPageChange={handlePageChange} />
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
      </div>
      {showModal && (
        <Modal title={editingItem ? 'Edit Brand' : 'Add Brand'} onClose={() => setShowModal(false)}>
          <div className="space-y-4">
            <div><label className="block text-sm font-bold mb-2">Brand Name</label><input type="text" className="input-field" value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} placeholder="Century" /></div>
            <div><label className="block text-sm font-bold mb-2">Slug</label><input type="text" className="input-field" value={formData.slug} onChange={e => setFormData({ ...formData, slug: e.target.value })} placeholder="century (auto-generated if empty)" /></div>
            <div><label className="flex items-center gap-3 cursor-pointer"><input type="checkbox" checked={formData.is_active} onChange={e => setFormData({ ...formData, is_active: e.target.checked })} className="w-5 h-5 accent-mk-red" /><span className="text-sm font-bold">Active</span></label></div>
          </div>
          <div className="flex gap-3 mt-6">
            <button onClick={() => setShowModal(false)} className="flex-1 px-4 py-2 border-2 border-gray-300 rounded-lg hover:bg-gray-100 font-bold">Cancel</button>
            <button onClick={handleSave} disabled={saving} className="flex-1 btn-primary disabled:opacity-50">{saving ? 'Saving...' : 'Save Brand'}</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ============================================================================
// PRODUCTS MODULE - API-BACKED CRUD
// ============================================================================
function ProductsModule() {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [brands, setBrands] = useState<Brand[]>([]);
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingItem, setEditingItem] = useState<Product | null>(null);
<<<<<<< HEAD

  const [searchTerm, setSearchTerm] = useState('');

  const emptyForm = {
    name: '', sku: '', hsn_code: '', isin: '', category_id: '', brand_id: '', brand_collection: '',
    vendor_id: '', description: '', unit: 'piece', price: '', mrp: '', stock_qty: '', min_order_qty: '1',
    image_url: '', specifications: '{}',
    length_mm: '', breadth_mm: '', width_mm: '', thickness_mm: '', weight_kg: '',
    box_length_mm: '', box_breadth_mm: '', box_width_mm: '', box_weight_kg: '',
    colour: '', grade: '', material: '', calibration: '', certification: '',
    termite_resistance: '', warranty: '', country_of_origin: 'India',
    customer_care_details: '', tech_sheet_url: '',
    manufactured_by: '', packaged_by: '', lead_time_days: '',
  };
  const [formData, setFormData] = useState(emptyForm);
=======
  const [formData, setFormData] = useState({
    name: '', sku: '', category_id: '', brand_id: '', description: '',
    unit: 'piece', price: '', mrp: '', stock_qty: '', min_order_qty: '1',
    specifications: '{}', tech_sheet_url: '', hsn_code: '', image_url: '',
    country_of_origin: '', colour: '', grade: '', material: '',
    thickness_mm: '', length_mm: '', breadth_mm: '', weight_kg: ''
  });
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const techSheetRef = useRef<HTMLInputElement>(null);
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState({ page: 1, pageSize: 20, total: 0, totalPages: 1 });

  const [search, setSearch] = useState('');

  const loadData = async (p = page, s = search) => {
    try {
<<<<<<< HEAD
      const [prodData, catData, brandData, vendorData] = await Promise.all([
        productService.getAll(), categoryService.getAll(), brandService.getAll(), vendorService.getAll()
      ]);
      setProducts(prodData); setCategories(catData); setBrands(brandData); setVendors(vendorData);
=======
      const [prodResult, catData, brandData] = await Promise.all([
        productService.getPaginated(p, 20, s), categoryService.getAll(), brandService.getAll()
      ]);
      setProducts(Array.isArray(prodResult.data) ? prodResult.data : []);
      setPagination(prodResult.pagination);
      setCategories(Array.isArray(catData) ? catData : []);
      setBrands(Array.isArray(brandData) ? brandData : []);
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
    } catch (err) { console.error('Failed to load products:', err); }
    finally { setLoading(false); }
  };

  useEffect(() => { loadData(); }, [page]);
  useEffect(() => { const t = setTimeout(() => { setPage(1); loadData(1, search); }, 300); return () => clearTimeout(t); }, [search]);

  const handlePageChange = (p: number) => { setPage(p); };

  const handleAdd = () => {
    setEditingItem(null);
<<<<<<< HEAD
    setFormData({ ...emptyForm });
=======
    setFormData({ name: '', sku: '', category_id: '', brand_id: '', description: '', unit: 'piece', price: '', mrp: '', stock_qty: '', min_order_qty: '1', specifications: '{}', tech_sheet_url: '', hsn_code: '', image_url: '', country_of_origin: '', colour: '', grade: '', material: '', thickness_mm: '', length_mm: '', breadth_mm: '', weight_kg: '' });
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
    setShowModal(true);
  };

  const handleEdit = (item: Product) => {
    setEditingItem(item);
    const p = item as any;
    setFormData({
      name: item.name, sku: item.sku || '', hsn_code: item.hsn_code || '', isin: item.isin || '',
      category_id: item.category_id || '', brand_id: item.brand_id || '', brand_collection: item.brand_collection || '',
      vendor_id: item.vendor_id || '', description: item.description || '', unit: item.unit || 'piece',
      price: String(item.price || ''), mrp: String(item.mrp || ''),
      stock_qty: String(item.stock_qty || ''), min_order_qty: String(item.min_order_qty || '1'),
<<<<<<< HEAD
      image_url: item.image_url || '', specifications: JSON.stringify(item.specifications || {}),
      length_mm: String(item.length_mm || ''), breadth_mm: String(item.breadth_mm || ''),
      width_mm: String(item.width_mm || ''), thickness_mm: String(item.thickness_mm || ''),
      weight_kg: String(item.weight_kg || ''),
      box_length_mm: String(item.box_length_mm || ''), box_breadth_mm: String(item.box_breadth_mm || ''),
      box_width_mm: String(item.box_width_mm || ''), box_weight_kg: String(item.box_weight_kg || ''),
      colour: item.colour || '', grade: item.grade || '', material: item.material || '',
      calibration: item.calibration || '', certification: item.certification || '',
      termite_resistance: item.termite_resistance || '', warranty: item.warranty || '',
      country_of_origin: item.country_of_origin || 'India',
      customer_care_details: item.customer_care_details || '', tech_sheet_url: item.tech_sheet_url || '',
      manufactured_by: item.manufactured_by || '', packaged_by: item.packaged_by || '',
      lead_time_days: String(item.lead_time_days || ''),
=======
      specifications: JSON.stringify(item.specifications || {}),
      tech_sheet_url: p.tech_sheet_url || '', hsn_code: p.hsn_code || '',
      image_url: p.image_url || '', country_of_origin: p.country_of_origin || '',
      colour: p.colour || '', grade: p.grade || '', material: p.material || '',
      thickness_mm: p.thickness_mm ? String(p.thickness_mm) : '',
      length_mm: p.length_mm ? String(p.length_mm) : '',
      breadth_mm: p.breadth_mm ? String(p.breadth_mm) : '',
      weight_kg: p.weight_kg ? String(p.weight_kg) : ''
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
    });
    setShowModal(true);
  };

<<<<<<< HEAD
  const numOrNull = (v: string) => v ? Number(v) : null;
=======
  const handleTechSheetUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.type !== 'application/pdf') { alert('Only PDF files are allowed'); return; }
    setUploading(true);
    try {
      const fd = new FormData();
      fd.append('file', file);
      const res = await apiService.upload('/upload', fd);
      setFormData({ ...formData, tech_sheet_url: res.url });
    } catch { alert('Failed to upload file. Please try again.'); }
    setUploading(false);
    if (techSheetRef.current) techSheetRef.current.value = '';
  };
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611

  const handleSave = async () => {
    setSaving(true);
    try {
      const payload: any = {
        ...formData,
        price: formData.price ? Number(formData.price) : 0,
        mrp: numOrNull(formData.mrp),
        stock_qty: formData.stock_qty ? Number(formData.stock_qty) : 0,
        min_order_qty: formData.min_order_qty ? Number(formData.min_order_qty) : 1,
        brand_id: formData.brand_id || null,
        category_id: formData.category_id || null,
<<<<<<< HEAD
        vendor_id: formData.vendor_id || null,
        image_url: formData.image_url || null,
        hsn_code: formData.hsn_code || null,
        isin: formData.isin || null,
        brand_collection: formData.brand_collection || null,
        length_mm: numOrNull(formData.length_mm), breadth_mm: numOrNull(formData.breadth_mm),
        width_mm: numOrNull(formData.width_mm), thickness_mm: numOrNull(formData.thickness_mm),
        weight_kg: numOrNull(formData.weight_kg),
        box_length_mm: numOrNull(formData.box_length_mm), box_breadth_mm: numOrNull(formData.box_breadth_mm),
        box_width_mm: numOrNull(formData.box_width_mm), box_weight_kg: numOrNull(formData.box_weight_kg),
        lead_time_days: numOrNull(formData.lead_time_days),
        colour: formData.colour || null, grade: formData.grade || null,
        material: formData.material || null, calibration: formData.calibration || null,
        certification: formData.certification || null, termite_resistance: formData.termite_resistance || null,
        warranty: formData.warranty || null, country_of_origin: formData.country_of_origin || 'India',
        customer_care_details: formData.customer_care_details || null,
        tech_sheet_url: formData.tech_sheet_url || null,
        manufactured_by: formData.manufactured_by || null, packaged_by: formData.packaged_by || null,
=======
        thickness_mm: formData.thickness_mm ? Number(formData.thickness_mm) : null,
        length_mm: formData.length_mm ? Number(formData.length_mm) : null,
        breadth_mm: formData.breadth_mm ? Number(formData.breadth_mm) : null,
        weight_kg: formData.weight_kg ? Number(formData.weight_kg) : null,
        hsn_code: formData.hsn_code || null,
        image_url: formData.image_url || null,
        country_of_origin: formData.country_of_origin || null,
        colour: formData.colour || null,
        grade: formData.grade || null,
        material: formData.material || null,
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
      };
      try { payload.specifications = JSON.parse(formData.specifications); } catch { payload.specifications = {}; }
      if (editingItem) { await productService.update(editingItem.id, payload); }
      else { await productService.create(payload); }
      await loadData(); setShowModal(false);
    } catch (err) { console.error('Save product error:', err); alert('Failed to save product.'); }
    finally { setSaving(false); }
  };

  const handleDelete = async (id: string) => {
    if (confirm('Delete this product?')) {
      try { await productService.delete(id); await loadData(); }
      catch (err) { console.error('Delete product error:', err); alert('Failed to delete product.'); }
    }
  };

  if (loading) return <LoadingSpinner />;

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-mk-gray">Products</h1>
        <div className="flex items-center gap-3">
          <SearchBar value={search} onChange={setSearch} placeholder="Search products..." />
          <button onClick={handleAdd} className="btn-primary flex items-center gap-2"><Plus className="w-5 h-5" /> Add Product</button>
        </div>
      </div>
      <div className="bg-white rounded-xl shadow-md p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input type="text" placeholder="Search by name, SKU, or brand..." className="input-field pl-10" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
          </div>
        </div>
        {(() => { const filtered = products.filter(p => !searchTerm || p.name.toLowerCase().includes(searchTerm.toLowerCase()) || (p.sku && p.sku.toLowerCase().includes(searchTerm.toLowerCase())) || (p.brand_name && p.brand_name.toLowerCase().includes(searchTerm.toLowerCase()))); return filtered.length === 0 ? <p className="text-gray-500 text-center py-8">No products found.</p> : (
          <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50"><tr>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Image</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">SKU</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Product Name</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">HSN</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Category</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Brand</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Price</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">MRP</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Stock</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Grade</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Status</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Actions</th>
            </tr></thead>
            <tbody>{filtered.map(product => (
              <tr key={product.id} className="border-t hover:bg-gray-50">
                <td className="px-4 py-4">{product.image_url ? <img src={product.image_url} alt={product.name} className="w-10 h-10 object-cover rounded" /> : <div className="w-10 h-10 bg-gray-100 rounded flex items-center justify-center"><Package className="w-5 h-5 text-gray-400" /></div>}</td>
                <td className="px-4 py-4 font-mono text-sm">{product.sku || '-'}</td>
                <td className="px-4 py-4 font-bold">{product.name}</td>
                <td className="px-4 py-4 text-sm font-mono">{product.hsn_code || '-'}</td>
                <td className="px-4 py-4 text-sm">{product.category_name || '-'}</td>
                <td className="px-4 py-4 text-sm">{product.brand_name || '-'}</td>
                <td className="px-4 py-4 text-sm font-bold text-mk-red">{product.price ? `₹${Number(product.price).toLocaleString()}` : '-'}</td>
                <td className="px-4 py-4 text-sm">{product.mrp ? `₹${Number(product.mrp).toLocaleString()}` : '-'}</td>
                <td className="px-4 py-4 text-sm">{product.stock_qty}</td>
                <td className="px-4 py-4 text-sm">{product.grade || '-'}</td>
                <td className="px-4 py-4"><span className={`px-3 py-1 rounded-full text-xs font-bold ${product.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>{product.is_active ? 'Active' : 'Inactive'}</span></td>
                <td className="px-4 py-4"><div className="flex gap-2">
                  <button onClick={() => handleEdit(product)} className="p-2 text-blue-600 hover:bg-blue-50 rounded"><Edit2 className="w-4 h-4" /></button>
                  <button onClick={() => handleDelete(product.id)} className="p-2 text-red-600 hover:bg-red-50 rounded"><Trash2 className="w-4 h-4" /></button>
                </div></td>
              </tr>
            ))}</tbody>
          </table>
<<<<<<< HEAD
          </div>
        ); })()}
=======
        )}
        <Pagination page={pagination.page} totalPages={pagination.totalPages} total={pagination.total} pageSize={pagination.pageSize} onPageChange={handlePageChange} />
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
      </div>
      {showModal && (
        <Modal title={editingItem ? 'Edit Product' : 'Add Product'} onClose={() => setShowModal(false)}>
          <div className="space-y-4 max-h-[70vh] overflow-y-auto pr-2">
            {/* Basic Info */}
            <h3 className="text-sm font-bold text-gray-500 uppercase border-b pb-1">Basic Info</h3>
            <div className="grid grid-cols-2 gap-4">
              <div><label className="block text-sm font-bold mb-2">Product Name *</label><input type="text" className="input-field" value={formData.name} onChange={e => setFormData({ ...formData, name: e.target.value })} placeholder="Century 18mm BWP Plywood" /></div>
              <div><label className="block text-sm font-bold mb-2">SKU</label><input type="text" className="input-field" value={formData.sku} onChange={e => setFormData({ ...formData, sku: e.target.value })} placeholder="PLY-CEN-18MM" /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><label className="block text-sm font-bold mb-2">HSN Code</label><input type="text" className="input-field" value={formData.hsn_code} onChange={e => setFormData({ ...formData, hsn_code: e.target.value })} placeholder="44129990" /></div>
              <div><label className="block text-sm font-bold mb-2">ISIN</label><input type="text" className="input-field" value={formData.isin} onChange={e => setFormData({ ...formData, isin: e.target.value })} placeholder="" /></div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div><label className="block text-sm font-bold mb-2">Category</label>
                <select className="input-field" value={formData.category_id} onChange={e => setFormData({ ...formData, category_id: e.target.value })}>
                  <option value="">Select Category</option>
                  {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <div><label className="block text-sm font-bold mb-2">Brand</label>
                <select className="input-field" value={formData.brand_id} onChange={e => setFormData({ ...formData, brand_id: e.target.value })}>
                  <option value="">Select Brand</option>
                  {brands.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}
                </select>
              </div>
              <div><label className="block text-sm font-bold mb-2">Vendor</label>
                <select className="input-field" value={formData.vendor_id} onChange={e => setFormData({ ...formData, vendor_id: e.target.value })}>
                  <option value="">Select Vendor</option>
                  {vendors.map(v => <option key={v.id} value={v.id}>{v.company_name}</option>)}
                </select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><label className="block text-sm font-bold mb-2">Brand Collection</label><input type="text" className="input-field" value={formData.brand_collection} onChange={e => setFormData({ ...formData, brand_collection: e.target.value })} placeholder="Premium" /></div>
            </div>
            {/* Image Upload */}
            <div>
              <label className="block text-sm font-bold mb-2">Product Image</label>
              <div className="flex items-start gap-4">
                {formData.image_url ? (
                  <div className="relative">
                    <img src={formData.image_url} alt="Product" className="w-24 h-24 object-cover rounded-lg border" />
                    <button type="button" onClick={() => setFormData({ ...formData, image_url: '' })} className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full w-5 h-5 flex items-center justify-center text-xs hover:bg-red-600">×</button>
                  </div>
                ) : (
                  <div className="w-24 h-24 bg-gray-100 rounded-lg border-2 border-dashed border-gray-300 flex items-center justify-center">
                    <Image className="w-8 h-8 text-gray-300" />
                  </div>
                )}
                <div className="flex-1">
                  <label className="flex items-center gap-2 px-4 py-2 bg-blue-50 text-blue-600 border-2 border-blue-200 rounded-lg cursor-pointer hover:bg-blue-100 font-bold text-sm w-fit">
                    <Upload className="w-4 h-4" /> Upload Image
                    <input type="file" accept="image/jpeg,image/png,image/webp,image/gif" className="hidden" onChange={async (e) => {
                      const file = e.target.files?.[0];
                      if (!file) return;
                      if (file.size > 5 * 1024 * 1024) { alert('Image must be under 5MB.'); return; }
                      try {
                        const url = await uploadService.uploadImage(file, 'products');
                        setFormData({ ...formData, image_url: url });
                      } catch (err) { console.error('Upload error:', err); alert('Failed to upload image.'); }
                    }} />
                  </label>
                  <p className="text-xs text-gray-400 mt-1">JPEG, PNG, WebP, GIF — max 5MB</p>
                  <input type="text" className="input-field text-xs mt-2" value={formData.image_url} onChange={e => setFormData({ ...formData, image_url: e.target.value })} placeholder="Or paste image URL manually" />
                </div>
              </div>
            </div>
            <div><label className="block text-sm font-bold mb-2">Description</label><textarea className="input-field" rows={2} value={formData.description} onChange={e => setFormData({ ...formData, description: e.target.value })} placeholder="Product description" /></div>

            {/* Pricing & Inventory */}
            <h3 className="text-sm font-bold text-gray-500 uppercase border-b pb-1 mt-4">Pricing & Inventory</h3>
            <div className="grid grid-cols-3 gap-4">
              <div><label className="block text-sm font-bold mb-2">Price (₹) *</label><input type="number" step="0.01" className="input-field" value={formData.price} onChange={e => setFormData({ ...formData, price: e.target.value })} placeholder="2500" /></div>
              <div><label className="block text-sm font-bold mb-2">MRP (₹)</label><input type="number" step="0.01" className="input-field" value={formData.mrp} onChange={e => setFormData({ ...formData, mrp: e.target.value })} placeholder="3000" /></div>
              <div><label className="block text-sm font-bold mb-2">Unit</label>
                <select className="input-field" value={formData.unit} onChange={e => setFormData({ ...formData, unit: e.target.value })}>
                  <option value="piece">Piece</option>
                  <option value="sq.mm">sq.mm</option>
                  <option value="mm">mm</option>
                  <option value="kg">Kg</option>
                  <option value="box">Box</option>
                  <option value="bundle">Bundle</option>
                  <option value="set">Set</option>
                  <option value="litre">Litre</option>
                  <option value="bag">Bag</option>
                  <option value="sqft">Sq Ft</option>
                </select>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div><label className="block text-sm font-bold mb-2">Stock Qty</label><input type="number" className="input-field" value={formData.stock_qty} onChange={e => setFormData({ ...formData, stock_qty: e.target.value })} placeholder="100" /></div>
              <div><label className="block text-sm font-bold mb-2">Min Order Qty</label><input type="number" className="input-field" value={formData.min_order_qty} onChange={e => setFormData({ ...formData, min_order_qty: e.target.value })} placeholder="1" /></div>
              <div><label className="block text-sm font-bold mb-2">Lead Time (days)</label><input type="number" className="input-field" value={formData.lead_time_days} onChange={e => setFormData({ ...formData, lead_time_days: e.target.value })} placeholder="7" /></div>
            </div>
<<<<<<< HEAD

            {/* Product Dimensions */}
            <h3 className="text-sm font-bold text-gray-500 uppercase border-b pb-1 mt-4">Product Dimensions</h3>
            <div className="grid grid-cols-5 gap-3">
              <div><label className="block text-xs font-bold mb-1">Length (mm)</label><input type="number" step="0.01" className="input-field" value={formData.length_mm} onChange={e => setFormData({ ...formData, length_mm: e.target.value })} /></div>
              <div><label className="block text-xs font-bold mb-1">Breadth (mm)</label><input type="number" step="0.01" className="input-field" value={formData.breadth_mm} onChange={e => setFormData({ ...formData, breadth_mm: e.target.value })} /></div>
              <div><label className="block text-xs font-bold mb-1">Width (mm)</label><input type="number" step="0.01" className="input-field" value={formData.width_mm} onChange={e => setFormData({ ...formData, width_mm: e.target.value })} /></div>
              <div><label className="block text-xs font-bold mb-1">Thickness (mm)</label><input type="number" step="0.01" className="input-field" value={formData.thickness_mm} onChange={e => setFormData({ ...formData, thickness_mm: e.target.value })} /></div>
              <div><label className="block text-xs font-bold mb-1">Weight (kg)</label><input type="number" step="0.01" className="input-field" value={formData.weight_kg} onChange={e => setFormData({ ...formData, weight_kg: e.target.value })} /></div>
            </div>

            {/* Box Dimensions */}
            <h3 className="text-sm font-bold text-gray-500 uppercase border-b pb-1 mt-4">Box / Packaging Dimensions</h3>
            <div className="grid grid-cols-4 gap-3">
              <div><label className="block text-xs font-bold mb-1">Box Length (mm)</label><input type="number" step="0.01" className="input-field" value={formData.box_length_mm} onChange={e => setFormData({ ...formData, box_length_mm: e.target.value })} /></div>
              <div><label className="block text-xs font-bold mb-1">Box Breadth (mm)</label><input type="number" step="0.01" className="input-field" value={formData.box_breadth_mm} onChange={e => setFormData({ ...formData, box_breadth_mm: e.target.value })} /></div>
              <div><label className="block text-xs font-bold mb-1">Box Width (mm)</label><input type="number" step="0.01" className="input-field" value={formData.box_width_mm} onChange={e => setFormData({ ...formData, box_width_mm: e.target.value })} /></div>
              <div><label className="block text-xs font-bold mb-1">Box Weight (kg)</label><input type="number" step="0.01" className="input-field" value={formData.box_weight_kg} onChange={e => setFormData({ ...formData, box_weight_kg: e.target.value })} /></div>
            </div>

            {/* Attributes */}
            <h3 className="text-sm font-bold text-gray-500 uppercase border-b pb-1 mt-4">Attributes</h3>
            <div className="grid grid-cols-3 gap-4">
              <div><label className="block text-sm font-bold mb-2">Colour</label><input type="text" className="input-field" value={formData.colour} onChange={e => setFormData({ ...formData, colour: e.target.value })} placeholder="Natural" /></div>
              <div><label className="block text-sm font-bold mb-2">Grade</label><input type="text" className="input-field" value={formData.grade} onChange={e => setFormData({ ...formData, grade: e.target.value })} placeholder="BWP / MR / BWR" /></div>
              <div><label className="block text-sm font-bold mb-2">Material</label><input type="text" className="input-field" value={formData.material} onChange={e => setFormData({ ...formData, material: e.target.value })} placeholder="Hardwood" /></div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div><label className="block text-sm font-bold mb-2">Calibration</label><input type="text" className="input-field" value={formData.calibration} onChange={e => setFormData({ ...formData, calibration: e.target.value })} /></div>
              <div><label className="block text-sm font-bold mb-2">Certification</label><input type="text" className="input-field" value={formData.certification} onChange={e => setFormData({ ...formData, certification: e.target.value })} placeholder="ISI / ISO" /></div>
              <div><label className="block text-sm font-bold mb-2">Termite Resistance</label><input type="text" className="input-field" value={formData.termite_resistance} onChange={e => setFormData({ ...formData, termite_resistance: e.target.value })} placeholder="Yes / No" /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><label className="block text-sm font-bold mb-2">Warranty</label><input type="text" className="input-field" value={formData.warranty} onChange={e => setFormData({ ...formData, warranty: e.target.value })} placeholder="25 Years" /></div>
              <div><label className="block text-sm font-bold mb-2">Country of Origin</label><input type="text" className="input-field" value={formData.country_of_origin} onChange={e => setFormData({ ...formData, country_of_origin: e.target.value })} placeholder="India" /></div>
            </div>

            {/* Manufacturer Info */}
            <h3 className="text-sm font-bold text-gray-500 uppercase border-b pb-1 mt-4">Manufacturer Info</h3>
            <div className="grid grid-cols-2 gap-4">
              <div><label className="block text-sm font-bold mb-2">Manufactured By</label><input type="text" className="input-field" value={formData.manufactured_by} onChange={e => setFormData({ ...formData, manufactured_by: e.target.value })} /></div>
              <div><label className="block text-sm font-bold mb-2">Packaged By</label><input type="text" className="input-field" value={formData.packaged_by} onChange={e => setFormData({ ...formData, packaged_by: e.target.value })} /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><label className="block text-sm font-bold mb-2">Customer Care Details</label><input type="text" className="input-field" value={formData.customer_care_details} onChange={e => setFormData({ ...formData, customer_care_details: e.target.value })} /></div>
              <div><label className="block text-sm font-bold mb-2">Tech Sheet URL</label><input type="text" className="input-field" value={formData.tech_sheet_url} onChange={e => setFormData({ ...formData, tech_sheet_url: e.target.value })} placeholder="https://..." /></div>
            </div>

            {/* Specifications JSON */}
            <h3 className="text-sm font-bold text-gray-500 uppercase border-b pb-1 mt-4">Specifications</h3>
=======
            <div className="grid grid-cols-3 gap-4">
              <div><label className="block text-sm font-bold mb-2">HSN Code</label><input type="text" className="input-field" value={formData.hsn_code} onChange={e => setFormData({ ...formData, hsn_code: e.target.value })} placeholder="44121000" /></div>
              <div><label className="block text-sm font-bold mb-2">Country of Origin</label><input type="text" className="input-field" value={formData.country_of_origin} onChange={e => setFormData({ ...formData, country_of_origin: e.target.value })} placeholder="India" /></div>
              <div><label className="block text-sm font-bold mb-2">Image URL</label><input type="text" className="input-field" value={formData.image_url} onChange={e => setFormData({ ...formData, image_url: e.target.value })} placeholder="/uploads/..." /></div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div><label className="block text-sm font-bold mb-2">Colour</label><input type="text" className="input-field" value={formData.colour} onChange={e => setFormData({ ...formData, colour: e.target.value })} placeholder="Natural" /></div>
              <div><label className="block text-sm font-bold mb-2">Grade</label><input type="text" className="input-field" value={formData.grade} onChange={e => setFormData({ ...formData, grade: e.target.value })} placeholder="BWP" /></div>
              <div><label className="block text-sm font-bold mb-2">Material</label><input type="text" className="input-field" value={formData.material} onChange={e => setFormData({ ...formData, material: e.target.value })} placeholder="Plywood" /></div>
            </div>
            <div className="grid grid-cols-4 gap-4">
              <div><label className="block text-sm font-bold mb-2">Thickness (mm)</label><input type="number" step="0.1" className="input-field" value={formData.thickness_mm} onChange={e => setFormData({ ...formData, thickness_mm: e.target.value })} /></div>
              <div><label className="block text-sm font-bold mb-2">Length (mm)</label><input type="number" className="input-field" value={formData.length_mm} onChange={e => setFormData({ ...formData, length_mm: e.target.value })} /></div>
              <div><label className="block text-sm font-bold mb-2">Breadth (mm)</label><input type="number" className="input-field" value={formData.breadth_mm} onChange={e => setFormData({ ...formData, breadth_mm: e.target.value })} /></div>
              <div><label className="block text-sm font-bold mb-2">Weight (kg)</label><input type="number" step="0.01" className="input-field" value={formData.weight_kg} onChange={e => setFormData({ ...formData, weight_kg: e.target.value })} /></div>
            </div>
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
            <div><label className="block text-sm font-bold mb-2">Specifications (JSON)</label><textarea className="input-field font-mono text-sm" rows={3} value={formData.specifications} onChange={e => setFormData({ ...formData, specifications: e.target.value })} placeholder='{"thickness": "18mm", "grade": "BWP"}' /></div>
            <div>
              <label className="block text-sm font-bold mb-2">Tech Data Sheet (PDF)</label>
              {formData.tech_sheet_url && (
                <div className="flex items-center gap-2 mb-2">
                  <a href={`${API_CONFIG.API_BASE_URL.replace('/api', '')}${formData.tech_sheet_url}`} target="_blank" rel="noopener noreferrer" className="text-sm text-blue-600 underline truncate max-w-[200px]">{formData.tech_sheet_url.split('/').pop()}</a>
                  <button type="button" onClick={() => setFormData({ ...formData, tech_sheet_url: '' })} className="text-xs text-red-500 hover:text-red-700">Remove</button>
                </div>
              )}
              <input ref={techSheetRef} type="file" accept=".pdf,application/pdf" onChange={handleTechSheetUpload}
                className="block w-full text-sm text-gray-500 file:mr-3 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:text-sm file:font-bold file:bg-red-50 file:text-mk-red hover:file:bg-red-100" />
              {uploading && <p className="text-xs text-gray-400 mt-1">Uploading...</p>}
            </div>
          </div>
          <div className="flex gap-3 mt-6">
            <button onClick={() => setShowModal(false)} className="flex-1 px-4 py-2 border-2 border-gray-300 rounded-lg hover:bg-gray-100 font-bold">Cancel</button>
            <button onClick={handleSave} disabled={saving} className="flex-1 btn-primary disabled:opacity-50">{saving ? 'Saving...' : 'Save Product'}</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ============================================================================
// DEALERS MODULE - API-BACKED CRUD
// ============================================================================
function DealersModule() {
  const [dealers, setDealers] = useState<Dealer[]>([]);
  const [zones, setZones] = useState<Zone[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingItem, setEditingItem] = useState<Dealer | null>(null);
  const [formData, setFormData] = useState({
    company_name: '', contact_name: '', email: '', phone: '', gstin: '',
<<<<<<< HEAD
    address: '', city: '', state: '', pincode: '', is_active: true as boolean
  });
  const [saving, setSaving] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
=======
    address: '', city: '', state: '', pincode: '', zone_id: ''
  });
  const [saving, setSaving] = useState(false);
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState({ page: 1, pageSize: 20, total: 0, totalPages: 1 });
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611

  const [search, setSearch] = useState('');

  const loadData = async (p = page, s = search) => {
    try {
      const [result, zoneData] = await Promise.all([dealerService.getPaginated(p, 20, s), zoneService.getAll()]);
      setDealers(Array.isArray(result.data) ? result.data : []);
      setPagination(result.pagination);
      setZones(Array.isArray(zoneData) ? zoneData : []);
    } catch (err) { console.error('Failed to load dealers:', err); }
    finally { setLoading(false); }
  };

  useEffect(() => { loadData(); }, [page]);
  useEffect(() => { const t = setTimeout(() => { setPage(1); loadData(1, search); }, 300); return () => clearTimeout(t); }, [search]);

  const handlePageChange = (p: number) => { setPage(p); };

  const handleAdd = () => {
    setEditingItem(null);
<<<<<<< HEAD
    setFormData({ company_name: '', contact_name: '', email: '', phone: '', gstin: '', address: '', city: '', state: '', pincode: '', is_active: true });
=======
    setFormData({ company_name: '', contact_name: '', email: '', phone: '', gstin: '', address: '', city: '', state: '', pincode: '', zone_id: '' });
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
    setShowModal(true);
  };

  const handleEdit = (item: Dealer) => {
    setEditingItem(item);
    setFormData({
      company_name: item.company_name, contact_name: item.contact_name || '',
      email: item.email || '', phone: item.phone || '', gstin: item.gstin || '',
      address: item.address || '', city: item.city || '', state: item.state || '', pincode: item.pincode || '',
<<<<<<< HEAD
      is_active: item.is_active !== false
=======
      zone_id: (item as any).zone_id ? String((item as any).zone_id) : ''
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
    });
    setShowModal(true);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const payload = { ...formData, zone_id: formData.zone_id ? Number(formData.zone_id) : null } as any;
      if (editingItem) { await dealerService.update(editingItem.id, payload); }
      else { await dealerService.create(payload); }
      await loadData(); setShowModal(false);
    } catch (err) { console.error('Save dealer error:', err); alert('Failed to save dealer.'); }
    finally { setSaving(false); }
  };

  const handleDelete = async (id: string) => {
    if (confirm('Delete this dealer?')) {
      try { await dealerService.delete(id); await loadData(); }
      catch (err) { console.error('Delete dealer error:', err); alert('Failed to delete dealer.'); }
    }
  };

  if (loading) return <LoadingSpinner />;

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-mk-gray">Dealer Management</h1>
        <div className="flex items-center gap-3">
          <SearchBar value={search} onChange={setSearch} placeholder="Search dealers..." />
          <button onClick={handleAdd} className="btn-primary flex items-center gap-2"><Plus className="w-5 h-5" /> Add Dealer</button>
        </div>
      </div>
      <div className="bg-white rounded-xl shadow-md p-6">
        <div className="flex items-center gap-3 mb-4"><div className="relative flex-1 max-w-md"><Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" /><input type="text" placeholder="Search by company, contact, or GSTIN..." className="input-field pl-10" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} /></div></div>
        {(() => { const filtered = dealers.filter(d => !searchTerm || d.company_name.toLowerCase().includes(searchTerm.toLowerCase()) || (d.contact_name && d.contact_name.toLowerCase().includes(searchTerm.toLowerCase())) || (d.gstin && d.gstin.toLowerCase().includes(searchTerm.toLowerCase()))); return filtered.length === 0 ? <p className="text-gray-500 text-center py-8">No dealers found.</p> : (
          <table className="w-full">
            <thead className="bg-gray-50"><tr>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Company</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Contact</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">GSTIN</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">City</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Status</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Actions</th>
            </tr></thead>
            <tbody>{filtered.map(dealer => (
              <tr key={dealer.id} className="border-t hover:bg-gray-50">
                <td className="px-4 py-4 font-bold">{dealer.company_name}</td>
                <td className="px-4 py-4 text-sm">{dealer.contact_name || '-'}<br/><span className="text-gray-400">{dealer.phone || ''}</span></td>
                <td className="px-4 py-4 font-mono text-sm">{dealer.gstin || '-'}</td>
                <td className="px-4 py-4 text-sm">{dealer.city || '-'}</td>
                <td className="px-4 py-4"><span className={`px-3 py-1 rounded-full text-xs font-bold ${dealer.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>{dealer.is_active ? 'Active' : 'Inactive'}</span></td>
                <td className="px-4 py-4"><div className="flex gap-2">
                  <button onClick={() => handleEdit(dealer)} className="p-2 text-blue-600 hover:bg-blue-50 rounded"><Edit2 className="w-4 h-4" /></button>
                  <button onClick={() => handleDelete(dealer.id)} className="p-2 text-red-600 hover:bg-red-50 rounded"><Trash2 className="w-4 h-4" /></button>
                </div></td>
              </tr>
            ))}</tbody>
          </table>
<<<<<<< HEAD
        ); })()}
=======
        )}
        <Pagination page={pagination.page} totalPages={pagination.totalPages} total={pagination.total} pageSize={pagination.pageSize} onPageChange={handlePageChange} />
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
      </div>
      {showModal && (
        <Modal title={editingItem ? 'Edit Dealer' : 'Add Dealer'} onClose={() => setShowModal(false)}>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div><label className="block text-sm font-bold mb-2">Company Name *</label><input type="text" className="input-field" value={formData.company_name} onChange={e => setFormData({ ...formData, company_name: e.target.value })} placeholder="Sharma Trading Co" /></div>
              <div><label className="block text-sm font-bold mb-2">Contact Name</label><input type="text" className="input-field" value={formData.contact_name} onChange={e => setFormData({ ...formData, contact_name: e.target.value })} placeholder="Rajesh Sharma" /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><label className="block text-sm font-bold mb-2">Phone</label><input type="text" className="input-field" value={formData.phone} onChange={e => setFormData({ ...formData, phone: e.target.value })} placeholder="9876543210" /></div>
              <div><label className="block text-sm font-bold mb-2">Email</label><input type="email" className="input-field" value={formData.email} onChange={e => setFormData({ ...formData, email: e.target.value })} placeholder="dealer@company.com" /></div>
            </div>
            <div><label className="block text-sm font-bold mb-2">GSTIN</label><input type="text" className="input-field" value={formData.gstin} onChange={e => setFormData({ ...formData, gstin: e.target.value })} placeholder="27AABCS1234D1Z5" /></div>
            <div><label className="block text-sm font-bold mb-2">Address</label><input type="text" className="input-field" value={formData.address} onChange={e => setFormData({ ...formData, address: e.target.value })} placeholder="Full address" /></div>
            <div className="grid grid-cols-3 gap-4">
              <div><label className="block text-sm font-bold mb-2">City</label><input type="text" className="input-field" value={formData.city} onChange={e => setFormData({ ...formData, city: e.target.value })} placeholder="Mumbai" /></div>
              <div><label className="block text-sm font-bold mb-2">State</label>
                <select className="input-field" value={formData.state} onChange={e => setFormData({ ...formData, state: e.target.value })}>
                  <option value="">Select State</option>
                  {INDIAN_STATES.map(s => <option key={s.code} value={s.code}>{s.name} ({s.code})</option>)}
                </select>
              </div>
              <div><label className="block text-sm font-bold mb-2">Pincode</label><input type="text" className="input-field" value={formData.pincode} onChange={e => setFormData({ ...formData, pincode: e.target.value })} placeholder="400001" /></div>
            </div>
<<<<<<< HEAD
            <div><label className="flex items-center gap-3 cursor-pointer"><input type="checkbox" checked={formData.is_active} onChange={e => setFormData({ ...formData, is_active: e.target.checked })} className="w-5 h-5 accent-mk-red" /><span className="text-sm font-bold">Active</span></label></div>
=======
            <div><label className="block text-sm font-bold mb-2">Zone</label>
              <select className="input-field" value={formData.zone_id} onChange={e => setFormData({ ...formData, zone_id: e.target.value })}>
                <option value="">Select Zone</option>
                {zones.map(z => <option key={z.id} value={z.id}>{z.name} ({z.code})</option>)}
              </select>
            </div>
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
          </div>
          <div className="flex gap-3 mt-6">
            <button onClick={() => setShowModal(false)} className="flex-1 px-4 py-2 border-2 border-gray-300 rounded-lg hover:bg-gray-100 font-bold">Cancel</button>
            <button onClick={handleSave} disabled={saving} className="flex-1 btn-primary disabled:opacity-50">{saving ? 'Saving...' : 'Save Dealer'}</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ============================================================================
// BUYERS MODULE - API-BACKED CRUD
// ============================================================================
function BuyersModule() {
  const [buyers, setBuyers] = useState<Buyer[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingItem, setEditingItem] = useState<Buyer | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [formData, setFormData] = useState({
    company_name: '', gstin: '', pan: '', company_type: '', company_address: '', billing_address: '',
    first_name: '', last_name: '', email: '', phone: ''
  });
  const [saving, setSaving] = useState(false);
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState({ page: 1, pageSize: 20, total: 0, totalPages: 1 });

  const [search, setSearch] = useState('');

  const loadData = async (p = page, s = search) => {
    try {
      const result = await buyerService.getPaginated(p, 20, s);
      setBuyers(Array.isArray(result.data) ? result.data : []);
      setPagination(result.pagination);
    } catch (err) { console.error('Failed to load buyers:', err); }
    finally { setLoading(false); }
  };

  useEffect(() => { loadData(); }, [page]);
  useEffect(() => { const t = setTimeout(() => { setPage(1); loadData(1, search); }, 300); return () => clearTimeout(t); }, [search]);

  const handlePageChange = (p: number) => { setPage(p); };

  const handleAdd = () => {
    setEditingItem(null);
    setFormData({ company_name: '', gstin: '', pan: '', company_type: '', company_address: '', billing_address: '', first_name: '', last_name: '', email: '', phone: '' });
    setShowModal(true);
  };

  const handleEdit = (item: Buyer) => {
    setEditingItem(item);
    setFormData({
      company_name: item.company_name, gstin: item.gstin || '', pan: (item as any).pan || '',
      company_type: item.company_type || '', company_address: (item as any).company_address || '',
      billing_address: (item as any).billing_address || '',
      first_name: item.first_name || '', last_name: item.last_name || '',
      email: item.email || '', phone: item.phone || ''
    });
    setShowModal(true);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      if (editingItem) { await buyerService.update(editingItem.id, formData); }
      else { await buyerService.create(formData); }
      await loadData(); setShowModal(false);
    } catch (err) { console.error('Save buyer error:', err); alert('Failed to save buyer.'); }
    finally { setSaving(false); }
  };

  const handleDelete = async (id: string) => {
    if (confirm('Deactivate this buyer?')) {
      try { await buyerService.delete(id); await loadData(); }
      catch (err) { console.error('Delete buyer error:', err); alert('Failed to deactivate buyer.'); }
    }
  };

  if (loading) return <LoadingSpinner />;

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-mk-gray">Buyer Management</h1>
        <div className="flex items-center gap-3">
          <SearchBar value={search} onChange={setSearch} placeholder="Search buyers..." />
          <button onClick={handleAdd} className="btn-primary flex items-center gap-2"><Plus className="w-5 h-5" /> Add Buyer</button>
        </div>
      </div>
      <div className="bg-white rounded-xl shadow-md p-6">
        <div className="flex items-center gap-3 mb-4"><div className="relative flex-1 max-w-md"><Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" /><input type="text" placeholder="Search by company, name, or email..." className="input-field pl-10" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} /></div></div>
        {(() => { const filtered = buyers.filter(b => !searchTerm || b.company_name.toLowerCase().includes(searchTerm.toLowerCase()) || (b.first_name && b.first_name.toLowerCase().includes(searchTerm.toLowerCase())) || (b.email && b.email.toLowerCase().includes(searchTerm.toLowerCase()))); return filtered.length === 0 ? <p className="text-gray-500 text-center py-8">No buyers found.</p> : (
          <table className="w-full">
            <thead className="bg-gray-50"><tr>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Company</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Contact Person</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Email</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Phone</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">GSTIN</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Type</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Status</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Actions</th>
            </tr></thead>
            <tbody>{filtered.map(buyer => (
              <tr key={buyer.id} className="border-t hover:bg-gray-50">
                <td className="px-4 py-4 font-bold">{buyer.company_name}</td>
                <td className="px-4 py-4 text-sm">{buyer.first_name} {buyer.last_name}</td>
                <td className="px-4 py-4 text-sm">{buyer.email}</td>
                <td className="px-4 py-4 text-sm">{buyer.phone}</td>
                <td className="px-4 py-4 font-mono text-sm">{buyer.gstin || '-'}</td>
                <td className="px-4 py-4 text-sm">{buyer.company_type || '-'}</td>
                <td className="px-4 py-4"><span className={`px-3 py-1 rounded-full text-xs font-bold ${buyer.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>{buyer.is_active ? 'Active' : 'Inactive'}</span></td>
                <td className="px-4 py-4"><div className="flex gap-2">
                  <button onClick={() => handleEdit(buyer)} className="p-2 text-blue-600 hover:bg-blue-50 rounded"><Edit2 className="w-4 h-4" /></button>
                  <button onClick={() => handleDelete(buyer.id)} className="p-2 text-red-600 hover:bg-red-50 rounded"><Trash2 className="w-4 h-4" /></button>
                </div></td>
              </tr>
            ))}</tbody>
          </table>
<<<<<<< HEAD
        ); })()}
=======
        )}
        <Pagination page={pagination.page} totalPages={pagination.totalPages} total={pagination.total} pageSize={pagination.pageSize} onPageChange={handlePageChange} />
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
      </div>
      {showModal && (
        <Modal title={editingItem ? 'Edit Buyer' : 'Add Buyer'} onClose={() => setShowModal(false)}>
          <div className="space-y-4">
            <div><label className="block text-sm font-bold mb-2">Company Name *</label><input type="text" className="input-field" value={formData.company_name} onChange={e => setFormData({ ...formData, company_name: e.target.value })} placeholder="ABC Builders Pvt Ltd" /></div>
            <div className="grid grid-cols-2 gap-4">
              <div><label className="block text-sm font-bold mb-2">First Name *</label><input type="text" className="input-field" value={formData.first_name} onChange={e => setFormData({ ...formData, first_name: e.target.value })} placeholder="Raj" /></div>
              <div><label className="block text-sm font-bold mb-2">Last Name *</label><input type="text" className="input-field" value={formData.last_name} onChange={e => setFormData({ ...formData, last_name: e.target.value })} placeholder="Patel" /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><label className="block text-sm font-bold mb-2">Email *</label><input type="email" className="input-field" value={formData.email} onChange={e => setFormData({ ...formData, email: e.target.value })} placeholder="raj@abc.com" /></div>
              <div><label className="block text-sm font-bold mb-2">Phone *</label><input type="text" className="input-field" value={formData.phone} onChange={e => setFormData({ ...formData, phone: e.target.value })} placeholder="9876543210" /></div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div><label className="block text-sm font-bold mb-2">GSTIN</label><input type="text" className="input-field" value={formData.gstin} onChange={e => setFormData({ ...formData, gstin: e.target.value })} placeholder="27AAACR5678C1Z9" /></div>
              <div><label className="block text-sm font-bold mb-2">PAN</label><input type="text" className="input-field" value={formData.pan} onChange={e => setFormData({ ...formData, pan: e.target.value })} placeholder="AAACR5678C" /></div>
              <div><label className="block text-sm font-bold mb-2">Company Type</label>
                <select className="input-field" value={formData.company_type} onChange={e => setFormData({ ...formData, company_type: e.target.value })}>
                  <option value="">Select Type</option>
                  <option value="Builder">Builder</option>
                  <option value="Contractor">Contractor</option>
                  <option value="Interior Designer">Interior Designer</option>
                  <option value="Architect">Architect</option>
                  <option value="Retailer">Retailer</option>
                  <option value="Other">Other</option>
                </select>
              </div>
            </div>
            <div><label className="block text-sm font-bold mb-2">Company Address</label><textarea className="input-field" rows={2} value={formData.company_address} onChange={e => setFormData({ ...formData, company_address: e.target.value })} placeholder="Full company address" /></div>
            <div><label className="block text-sm font-bold mb-2">Billing Address</label><textarea className="input-field" rows={2} value={formData.billing_address} onChange={e => setFormData({ ...formData, billing_address: e.target.value })} placeholder="Billing address (if different)" /></div>
          </div>
          <div className="flex gap-3 mt-6">
            <button onClick={() => setShowModal(false)} className="flex-1 px-4 py-2 border-2 border-gray-300 rounded-lg hover:bg-gray-100 font-bold">Cancel</button>
            <button onClick={handleSave} disabled={saving} className="flex-1 btn-primary disabled:opacity-50">{saving ? 'Saving...' : 'Save Buyer'}</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ============================================================================
// ORDERS MODULE - API-BACKED FULL CRUD
// ============================================================================
function OrdersModule() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
<<<<<<< HEAD
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
=======
  const [page, setPage] = useState(1);
  const [pagination, setPagination] = useState({ page: 1, pageSize: 20, total: 0, totalPages: 1 });
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611

  // Create modal
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [buyers, setBuyers] = useState<Buyer[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [orderForm, setOrderForm] = useState({ buyer_id: '', vendor_id: '', shipping_address: '', notes: '' });
  const [orderItems, setOrderItems] = useState<Array<{ product_id: string; product_name: string; sku: string; quantity: number; unit_price: number }>>([]);

  // Detail / transition view
  const [selectedOrder, setSelectedOrder] = useState<OrderDetail | null>(null);
  const [statusHistory, setStatusHistory] = useState<StatusHistoryEntry[]>([]);
  const [allowedTransitions, setAllowedTransitions] = useState<string[]>([]);
  const [transitionNotes, setTransitionNotes] = useState('');
  const [loadingDetail, setLoadingDetail] = useState(false);

  const statusColors: Record<string, string> = {
    pending: 'bg-yellow-100 text-yellow-800',
    pending_dealer_approval: 'bg-orange-100 text-orange-800',
    confirmed: 'bg-blue-100 text-blue-800',
    dispatched: 'bg-indigo-100 text-indigo-800',
    in_transit: 'bg-purple-100 text-purple-800',
    delivered: 'bg-green-100 text-green-800',
    partially_delivered: 'bg-teal-100 text-teal-800',
    cancelled: 'bg-red-100 text-red-800',
    disputed: 'bg-red-200 text-red-900',
  };

  const statusTransitionMap: Record<string, string[]> = {
    pending: ['confirmed', 'pending_dealer_approval', 'cancelled'],
    pending_dealer_approval: ['confirmed', 'cancelled'],
    confirmed: ['dispatched', 'cancelled'],
    dispatched: ['in_transit'],
    in_transit: ['delivered', 'partially_delivered'],
    partially_delivered: ['delivered', 'disputed'],
    delivered: ['disputed'],
    disputed: [],
    cancelled: [],
  };

<<<<<<< HEAD
  const loadData = async () => {
    try {
      const params: Record<string, any> = { limit: 200 };
      if (statusFilter) params.status = statusFilter;
      if (searchTerm) params.search = searchTerm;
      const data = await orderService.getAll(params);
      setOrders(data);
=======
  const [search, setSearch] = useState('');

  const loadData = async (p = page, s = search) => {
    try {
      const result = await orderService.getPaginated(p, 20, s);
      setOrders(Array.isArray(result.data) ? result.data : []);
      setPagination(result.pagination);
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
    } catch (err) { console.error('Failed to load orders:', err); }
    finally { setLoading(false); }
  };

<<<<<<< HEAD
  useEffect(() => { loadData(); }, [statusFilter]);
=======
  useEffect(() => { loadData(); }, [page]);
  useEffect(() => { const t = setTimeout(() => { setPage(1); loadData(1, search); }, 300); return () => clearTimeout(t); }, [search]);

  const handlePageChange = (p: number) => { setPage(p); };
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611

  const handleSearch = () => { setLoading(true); loadData(); };

  const viewOrderDetail = async (order: Order) => {
    setLoadingDetail(true);
    try {
      const detail = await orderService.getById(order.id);
      setSelectedOrder(detail);
      setAllowedTransitions(statusTransitionMap[detail.status] || []);
      setTransitionNotes('');
      // Load history separately — don't block detail view if it fails
      try {
        const history = await orderService.getStatusHistory(order.id);
        setStatusHistory(history);
      } catch (err) {
        console.error('Failed to load status history:', err);
        setStatusHistory([]);
      }
    } catch (err) { console.error('Failed to load order detail:', err); }
    finally { setLoadingDetail(false); }
  };

  const handleTransition = async (newStatus: string) => {
    if (!selectedOrder) return;
    setSaving(true);
    try {
      const result = await orderService.transitionStatus(selectedOrder.id, newStatus, transitionNotes || undefined);
      setAllowedTransitions(result.allowed_transitions || statusTransitionMap[newStatus] || []);
      setTransitionNotes('');
      // Reload detail and history
      const [detail, history] = await Promise.all([
        orderService.getById(selectedOrder.id),
        orderService.getStatusHistory(selectedOrder.id),
      ]);
      setSelectedOrder(detail);
      setStatusHistory(history);
      loadData();
    } catch (err: any) {
      alert(err?.response?.data?.message || 'Transition failed.');
    } finally { setSaving(false); }
  };

  const handleCancel = async (id: string) => {
    if (confirm('Cancel this order? Inventory will be restored.')) {
      try { await orderService.delete(id); setSelectedOrder(null); await loadData(); }
      catch (err) { console.error('Cancel order error:', err); alert('Failed to cancel order.'); }
    }
  };

  // Create order handlers
  const handleAdd = async () => {
    setOrderForm({ buyer_id: '', vendor_id: '', shipping_address: '', notes: '' });
    setOrderItems([]);
    try {
<<<<<<< HEAD
      const [buyerData, productData] = await Promise.all([buyerService.getAll(), productService.getAll()]);
      setBuyers(buyerData); setProducts(productData);
=======
      const [buyerData, productData] = await Promise.all([
        buyerService.getAll(), productService.getAll()
      ]);
      setBuyers(Array.isArray(buyerData) ? buyerData : []);
      setProducts(Array.isArray(productData) ? productData : []);
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
    } catch (err) { console.error('Failed to load form data:', err); }
    setShowCreateModal(true);
  };
  const addOrderItem = () => { setOrderItems([...orderItems, { product_id: '', product_name: '', sku: '', quantity: 1, unit_price: 0 }]); };
  const updateOrderItem = (index: number, field: string, value: any) => {
    const updated = [...orderItems];
    (updated[index] as any)[field] = value;
    if (field === 'product_id') {
      const prod = products.find(p => p.id === value);
      if (prod) { updated[index].product_name = prod.name; updated[index].sku = prod.sku || ''; updated[index].unit_price = Number(prod.price) || 0; }
    }
    setOrderItems(updated);
  };
  const removeOrderItem = (index: number) => { setOrderItems(orderItems.filter((_, i) => i !== index)); };
  const handleCreateOrder = async () => {
    if (!orderForm.buyer_id || orderItems.length === 0) { alert('Please select buyer and add at least one item.'); return; }
    setSaving(true);
    try {
      await orderService.create({ ...orderForm, items: orderItems.map(i => ({ product_id: i.product_id, quantity: i.quantity, unit_price: i.unit_price })) });
      await loadData(); setShowCreateModal(false);
    } catch (err) { console.error('Create order error:', err); alert('Failed to create order.'); }
    finally { setSaving(false); }
  };

<<<<<<< HEAD
  if (loading && orders.length === 0) return <LoadingSpinner />;
=======
  const handleEdit = (order: Order) => {
    setEditingOrder(order);
    setEditForm({
      status: order.status, notes: order.notes || '',
      shipping_address: order.shipping_address || ''
    });
    setShowEditModal(true);
  };

  const handleUpdateOrder = async () => {
    if (!editingOrder) return;
    setSaving(true);
    try {
      await orderService.update(editingOrder.id, editForm);
      await loadData(); setShowEditModal(false);
    } catch (err) { console.error('Update order error:', err); alert('Failed to update order.'); }
    finally { setSaving(false); }
  };

  const statusTransitions: Record<string, string[]> = {
    pending: ['confirmed', 'cancelled'],
    confirmed: ['processing', 'cancelled'],
    processing: ['shipped', 'cancelled'],
    shipped: ['delivered'],
  };

  const handleStatusChange = async (id: string, newStatus: string) => {
    const label = newStatus.charAt(0).toUpperCase() + newStatus.slice(1);
    if (!confirm(`Change order status to "${label}"?`)) return;
    try {
      await apiService.update('/orders', `${id}/status`, { status: newStatus } as any);
      await loadData();
    } catch (err: any) {
      alert(err?.response?.data?.message || 'Failed to update status.');
    }
  };

  const handleCancel = async (id: string) => {
    if (confirm('Cancel this order? Stock will be restored.')) {
      try { await orderService.delete(id); await loadData(); }
      catch (err) { console.error('Cancel order error:', err); alert('Failed to cancel order.'); }
    }
  };

  if (loading) return <LoadingSpinner />;

  const statusColors: Record<string, string> = {
    pending: 'bg-yellow-100 text-yellow-800',
    confirmed: 'bg-blue-100 text-blue-800',
    processing: 'bg-indigo-100 text-indigo-800',
    shipped: 'bg-purple-100 text-purple-800',
    delivered: 'bg-green-100 text-green-800',
    cancelled: 'bg-red-100 text-red-800',
  };
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611

  const subtotal = orderItems.reduce((sum, i) => sum + i.quantity * i.unit_price, 0);

  // ---- DETAIL VIEW ----
  if (selectedOrder) {
    return (
      <div>
        <button onClick={() => setSelectedOrder(null)} className="flex items-center gap-1 text-sm text-gray-500 hover:text-gray-800 mb-4 font-bold">
          ← Back to Orders
        </button>

        <div className="flex items-start justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold text-mk-gray">{selectedOrder.order_number}</h1>
            <p className="text-sm text-gray-500 mt-1">Created {new Date(selectedOrder.created_at).toLocaleString()}</p>
          </div>
          <span className={`px-4 py-2 rounded-full text-sm font-bold ${statusColors[selectedOrder.status] || 'bg-gray-100'}`}>
            {selectedOrder.status.replace(/_/g, ' ').toUpperCase()}
          </span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left column — Order info + Items */}
          <div className="lg:col-span-2 space-y-6">
            {/* Order Summary */}
            <div className="bg-white rounded-xl shadow-md p-6">
              <h2 className="text-lg font-bold mb-3">Order Summary</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div><p className="text-gray-500">Buyer</p><p className="font-bold">{selectedOrder.buyer_company || '-'}</p></div>
                <div><p className="text-gray-500">Dealer</p><p className="font-bold">{selectedOrder.dealer_company || '-'}</p></div>
                <div><p className="text-gray-500">Payment</p><p className="font-bold">{(selectedOrder.payment_method || 'COD').toUpperCase()}</p></div>
                <div><p className="text-gray-500">Payment Status</p><p className="font-bold">{(selectedOrder.payment_status || 'pending').toUpperCase()}</p></div>
              </div>
              {selectedOrder.shipping_address && (
                <div className="mt-3 text-sm"><p className="text-gray-500">Shipping Address</p><p className="font-bold">{selectedOrder.shipping_address}</p></div>
              )}
              {selectedOrder.notes && (
                <div className="mt-3 text-sm"><p className="text-gray-500">Notes</p><p>{selectedOrder.notes}</p></div>
              )}
            </div>

            {/* Line Items */}
            <div className="bg-white rounded-xl shadow-md p-6">
              <h2 className="text-lg font-bold mb-3">Line Items ({selectedOrder.items?.length || 0})</h2>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50"><tr>
                    <th className="px-4 py-2 text-left text-xs font-bold text-gray-600 uppercase">Product</th>
                    <th className="px-4 py-2 text-right text-xs font-bold text-gray-600 uppercase">Qty</th>
                    <th className="px-4 py-2 text-right text-xs font-bold text-gray-600 uppercase">Unit Price</th>
                    <th className="px-4 py-2 text-right text-xs font-bold text-gray-600 uppercase">Total</th>
                    <th className="px-4 py-2 text-center text-xs font-bold text-gray-600 uppercase">Fulfillment</th>
                  </tr></thead>
                  <tbody>{(selectedOrder.items || []).map((item: OrderLineItem) => (
                    <tr key={item.id} className="border-t">
                      <td className="px-4 py-3">
                        <p className="font-bold text-sm">{item.product_name}</p>
                        {item.sku && <p className="text-xs text-gray-400">{item.sku}</p>}
                      </td>
                      <td className="px-4 py-3 text-right font-bold">{item.quantity}</td>
                      <td className="px-4 py-3 text-right text-sm">₹{Number(item.unit_price).toLocaleString()}</td>
                      <td className="px-4 py-3 text-right font-bold">₹{Number(item.total_price).toLocaleString()}</td>
                      <td className="px-4 py-3 text-center">
                        {item.fulfillment_status === 'back_order' ? (
                          <span className="px-2 py-1 bg-orange-100 text-orange-700 rounded-full text-xs font-bold">Back Order ({item.quantity_back_order})</span>
                        ) : (
                          <span className="px-2 py-1 bg-green-100 text-green-700 rounded-full text-xs font-bold">In Stock</span>
                        )}
                      </td>
                    </tr>
                  ))}</tbody>
                  <tfoot><tr className="border-t-2">
                    <td colSpan={3} className="px-4 py-3 text-right font-bold text-lg">Total</td>
                    <td className="px-4 py-3 text-right font-bold text-lg text-mk-red">₹{Number(selectedOrder.total_amount).toLocaleString()}</td>
                    <td></td>
                  </tr></tfoot>
                </table>
              </div>
            </div>
          </div>

          {/* Right column — Status transition + History */}
          <div className="space-y-6">
            {/* Status Transition */}
            <div className="bg-white rounded-xl shadow-md p-6">
              <h2 className="text-lg font-bold mb-3">Update Status</h2>
              {allowedTransitions.length === 0 ? (
                <p className="text-sm text-gray-400">No transitions available — order is in a terminal state.</p>
              ) : (
                <div className="space-y-3">
                  <div>
                    <label className="block text-sm font-bold mb-1">Transition Notes</label>
                    <input type="text" className="input-field text-sm" placeholder="Optional notes..." value={transitionNotes} onChange={e => setTransitionNotes(e.target.value)} />
                  </div>
                  <div className="space-y-2">
                    {allowedTransitions.map(status => (
                      <button key={status} onClick={() => handleTransition(status)} disabled={saving}
                        className="w-full flex items-center justify-between px-4 py-2.5 border-2 rounded-lg font-bold text-sm hover:bg-gray-50 disabled:opacity-50">
                        <span className="flex items-center gap-2">
                          <ChevronRight className="w-4 h-4" />
                          {status.replace(/_/g, ' ').toUpperCase()}
                        </span>
                        <span className={`px-2 py-0.5 rounded-full text-[10px] ${statusColors[status] || 'bg-gray-100'}`}>{status}</span>
                      </button>
                    ))}
                  </div>
                  {selectedOrder.status !== 'delivered' && selectedOrder.status !== 'cancelled' && (
                    <button onClick={() => handleCancel(selectedOrder.id)} className="w-full px-4 py-2 bg-red-50 text-red-600 border-2 border-red-200 rounded-lg font-bold text-sm hover:bg-red-100 mt-2">
                      Cancel Order
                    </button>
                  )}
                </div>
              )}
            </div>

            {/* Status History / Audit Trail */}
            <div className="bg-white rounded-xl shadow-md p-6">
              <h2 className="text-lg font-bold mb-3 flex items-center gap-2"><Clock className="w-5 h-5" /> Status History</h2>
              {statusHistory.length === 0 ? (
                <p className="text-sm text-gray-400">No status changes recorded.</p>
              ) : (
                <div className="space-y-3">
                  {statusHistory.map((entry) => (
                    <div key={entry.id} className="relative pl-6 pb-3 border-l-2 border-gray-200 last:border-transparent">
                      <div className="absolute -left-[7px] top-1 w-3 h-3 rounded-full bg-mk-red"></div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${statusColors[entry.from_status] || 'bg-gray-100'}`}>{entry.from_status || 'created'}</span>
                        <ChevronRight className="w-3 h-3 text-gray-400" />
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${statusColors[entry.to_status] || 'bg-gray-100'}`}>{entry.to_status}</span>
                      </div>
                      <p className="text-xs text-gray-400 mt-1">{new Date(entry.created_at).toLocaleString()}</p>
                      {entry.changed_by_email && <p className="text-xs text-gray-400">by {entry.changed_by_email}</p>}
                      {entry.notes && <p className="text-xs text-gray-600 mt-1 italic">"{entry.notes}"</p>}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ---- LIST VIEW ----
  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-mk-gray">Order Management</h1>
        <div className="flex items-center gap-3">
          <SearchBar value={search} onChange={setSearch} placeholder="Search orders..." />
          <button onClick={handleAdd} className="btn-primary flex items-center gap-2"><Plus className="w-5 h-5" /> Create Order</button>
        </div>
      </div>

      {/* Search + Filter bar */}
      <div className="flex items-center gap-3 mb-4">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input type="text" placeholder="Search by order # or buyer..." className="input-field pl-10" value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSearch()} />
        </div>
        <select className="input-field w-48" value={statusFilter} onChange={e => setStatusFilter(e.target.value)}>
          <option value="">All Statuses</option>
          {Object.keys(statusColors).map(s => <option key={s} value={s}>{s.replace(/_/g, ' ')}</option>)}
        </select>
        <button onClick={handleSearch} className="px-4 py-2 border-2 border-gray-300 rounded-lg hover:bg-gray-100 font-bold text-sm">Search</button>
      </div>

      <div className="bg-white rounded-xl shadow-md p-6">
        {orders.length === 0 ? <p className="text-gray-500 text-center py-8">No orders found.</p> : (
          <div className="overflow-x-auto"><table className="w-full">
            <thead className="bg-gray-50"><tr>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Order #</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Buyer</th>
              <th className="px-4 py-3 text-right text-xs font-bold text-gray-600 uppercase">Amount</th>
              <th className="px-4 py-3 text-center text-xs font-bold text-gray-600 uppercase">Status</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Date</th>
              <th className="px-4 py-3 text-center text-xs font-bold text-gray-600 uppercase">Actions</th>
            </tr></thead>
            <tbody>{orders.map(order => (
              <tr key={order.id} className="border-t hover:bg-gray-50 cursor-pointer" onClick={() => viewOrderDetail(order)}>
                <td className="px-4 py-4 font-bold">{order.order_number}</td>
                <td className="px-4 py-4 text-sm">{order.buyer_company || '-'}</td>
                <td className="px-4 py-4 font-bold text-mk-red text-right">₹{Number(order.total_amount || 0).toLocaleString()}</td>
                <td className="px-4 py-4 text-center"><span className={`px-3 py-1 rounded-full text-xs font-bold ${statusColors[order.status] || 'bg-gray-100 text-gray-800'}`}>{order.status.replace(/_/g, ' ')}</span></td>
                <td className="px-4 py-4 text-sm">{new Date(order.created_at).toLocaleDateString()}</td>
<<<<<<< HEAD
                <td className="px-4 py-4 text-center" onClick={e => e.stopPropagation()}>
                  <div className="flex justify-center gap-2">
                    <button onClick={() => viewOrderDetail(order)} className="p-2 text-blue-600 hover:bg-blue-50 rounded" title="View Details"><Eye className="w-4 h-4" /></button>
                    {order.status !== 'delivered' && order.status !== 'cancelled' && (
                      <button onClick={() => handleCancel(order.id)} className="p-2 text-red-600 hover:bg-red-50 rounded" title="Cancel"><Trash2 className="w-4 h-4" /></button>
                    )}
                  </div>
                </td>
=======
                <td className="px-4 py-4"><div className="flex gap-2 flex-wrap">
                  <button onClick={() => handleEdit(order)} className="p-2 text-blue-600 hover:bg-blue-50 rounded" title="Edit"><Edit2 className="w-4 h-4" /></button>
                  {(statusTransitions[order.status] || []).filter(s => s !== 'cancelled').map(s => (
                    <button key={s} onClick={() => handleStatusChange(order.id, s)}
                      className="px-2 py-1 text-xs font-bold rounded bg-blue-50 text-blue-700 hover:bg-blue-100 capitalize">{s}</button>
                  ))}
                  {order.status !== 'delivered' && order.status !== 'cancelled' && (
                    <button onClick={() => handleCancel(order.id)} className="px-2 py-1 text-xs font-bold rounded bg-red-50 text-red-600 hover:bg-red-100">Cancel</button>
                  )}
                </div></td>
>>>>>>> 08b0a2ccc91c0ae885575805329c81b1a4e70611
              </tr>
            ))}</tbody>
          </table></div>
        )}
        <Pagination page={pagination.page} totalPages={pagination.totalPages} total={pagination.total} pageSize={pagination.pageSize} onPageChange={handlePageChange} />
      </div>

      {loadingDetail && (
        <div className="fixed inset-0 bg-black bg-opacity-30 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl p-8 shadow-xl"><LoadingSpinner /></div>
        </div>
      )}

      {/* CREATE ORDER MODAL */}
      {showCreateModal && (
        <Modal title="Create New Order" onClose={() => setShowCreateModal(false)}>
          <div className="space-y-4">
            <div><label className="block text-sm font-bold mb-2">Buyer *</label>
              <select className="input-field" value={orderForm.buyer_id} onChange={e => setOrderForm({ ...orderForm, buyer_id: e.target.value })}>
                <option value="">Select Buyer</option>
                {buyers.map(b => <option key={b.id} value={b.id}>{b.company_name || `${b.first_name} ${b.last_name}`}</option>)}
              </select>
            </div>
            <div><label className="block text-sm font-bold mb-2">Shipping Address</label><input type="text" className="input-field" value={orderForm.shipping_address} onChange={e => setOrderForm({ ...orderForm, shipping_address: e.target.value })} placeholder="Full delivery address" /></div>
            <p className="text-sm font-bold text-gray-500 uppercase mt-4">Order Items</p>
            {orderItems.map((item, idx) => (
              <div key={idx} className="flex gap-2 items-end bg-gray-50 p-3 rounded-lg">
                <div className="flex-1"><label className="block text-xs font-bold mb-1">Product</label>
                  <select className="input-field text-sm" value={item.product_id} onChange={e => updateOrderItem(idx, 'product_id', e.target.value)}>
                    <option value="">Select</option>
                    {products.map(p => <option key={p.id} value={p.id}>{p.name} {p.sku ? `(${p.sku})` : ''}</option>)}
                  </select>
                </div>
                <div className="w-20"><label className="block text-xs font-bold mb-1">Qty</label>
                  <input type="number" min="1" className="input-field text-sm" value={item.quantity} onChange={e => updateOrderItem(idx, 'quantity', Number(e.target.value))} />
                </div>
                <div className="w-28"><label className="block text-xs font-bold mb-1">Unit Price</label>
                  <input type="number" min="0" step="0.01" className="input-field text-sm" value={item.unit_price} onChange={e => updateOrderItem(idx, 'unit_price', Number(e.target.value))} />
                </div>
                <div className="w-24 text-sm font-bold pt-5">₹{(item.quantity * item.unit_price).toLocaleString()}</div>
                <button onClick={() => removeOrderItem(idx)} className="p-2 text-red-600 hover:bg-red-100 rounded mb-0.5"><X className="w-4 h-4" /></button>
              </div>
            ))}
            <button onClick={addOrderItem} className="text-sm text-blue-600 font-bold hover:underline flex items-center gap-1"><Plus className="w-4 h-4" /> Add Item</button>
            {orderItems.length > 0 && (
              <div className="bg-gray-50 p-4 rounded-lg text-right">
                <p className="text-lg font-bold text-mk-red">Total: ₹{subtotal.toLocaleString()}</p>
              </div>
            )}
            <div><label className="block text-sm font-bold mb-2">Notes</label><textarea className="input-field" rows={2} value={orderForm.notes} onChange={e => setOrderForm({ ...orderForm, notes: e.target.value })} /></div>
          </div>
          <div className="flex gap-3 mt-6">
            <button onClick={() => setShowCreateModal(false)} className="flex-1 px-4 py-2 border-2 border-gray-300 rounded-lg hover:bg-gray-100 font-bold">Cancel</button>
            <button onClick={handleCreateOrder} disabled={saving} className="flex-1 btn-primary disabled:opacity-50">{saving ? 'Creating...' : 'Create Order'}</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ============================================================================
// COUPONS MODULE - API-BACKED CRUD
// ============================================================================
function CouponsModule() {
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingCoupon, setEditingCoupon] = useState<Coupon | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [formData, setFormData] = useState({ code: '', description: '', discount_type: 'percentage', discount_value: '', min_order_amount: '', max_discount: '', usage_limit: '', valid_from: '', valid_until: '', is_active: true as boolean });
  const [saving, setSaving] = useState(false);

  const loadData = async () => {
    try { const data = await couponService.getAll(); setCoupons(data); }
    catch (err) { console.error('Failed to load coupons:', err); }
    finally { setLoading(false); }
  };

  useEffect(() => { loadData(); }, []);

  const handleAdd = () => { setEditingCoupon(null); setFormData({ code: '', description: '', discount_type: 'percentage', discount_value: '', min_order_amount: '', max_discount: '', usage_limit: '', valid_from: '', valid_until: '', is_active: true }); setShowModal(true); };
  const handleEdit = (c: Coupon) => {
    setEditingCoupon(c);
    setFormData({
      code: c.code || '', description: c.description || '', discount_type: c.discount_type || 'percentage',
      discount_value: String(c.discount_value ?? ''), min_order_amount: String(c.min_order_amount ?? ''),
      max_discount: String(c.max_discount ?? ''), usage_limit: String(c.usage_limit ?? ''),
      valid_from: c.valid_from ? String(c.valid_from).slice(0, 10) : '',
      valid_until: c.valid_until ? String(c.valid_until).slice(0, 10) : '',
      is_active: c.is_active !== false,
    });
    setShowModal(true);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      if (editingCoupon) { await couponService.update(editingCoupon.id, formData); }
      else { await couponService.create(formData); }
      await loadData(); setShowModal(false);
    } catch (err) { console.error('Save coupon error:', err); alert('Failed to save coupon.'); }
    finally { setSaving(false); }
  };

  const handleDelete = async (id: string) => {
    if (confirm('Delete this coupon?')) {
      try { await couponService.delete(id); await loadData(); }
      catch (err) { console.error('Delete coupon error:', err); alert('Failed to delete coupon.'); }
    }
  };

  if (loading) return <LoadingSpinner />;

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-mk-gray">Coupons</h1>
        <button onClick={handleAdd} className="btn-primary flex items-center gap-2"><Plus className="w-5 h-5" /> Add Coupon</button>
      </div>
      <div className="bg-white rounded-xl shadow-md p-6">
        <div className="flex items-center gap-3 mb-4"><div className="relative flex-1 max-w-md"><Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" /><input type="text" placeholder="Search by code or description..." className="input-field pl-10" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} /></div></div>
        {(() => { const filtered = coupons.filter(c => !searchTerm || c.code.toLowerCase().includes(searchTerm.toLowerCase()) || (c.description && c.description.toLowerCase().includes(searchTerm.toLowerCase()))); return filtered.length === 0 ? <p className="text-gray-500 text-center py-8">No coupons found.</p> : (
          <table className="w-full">
            <thead className="bg-gray-50"><tr>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Code</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Description</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Type</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Value</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Min Order</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Usage</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Valid Until</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Status</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Actions</th>
            </tr></thead>
            <tbody>{coupons.map(c => (
              <tr key={c.id} className="border-t hover:bg-gray-50">
                <td className="px-4 py-4 font-bold">{c.code}</td>
                <td className="px-4 py-4 text-sm text-gray-500 max-w-[200px] truncate">{c.description || '-'}</td>
                <td className="px-4 py-4"><span className={`px-3 py-1 rounded-full text-xs font-bold ${c.discount_type === 'percentage' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'}`}>{c.discount_type}</span></td>
                <td className="px-4 py-4 font-bold text-mk-red">{c.discount_type === 'percentage' ? `${c.discount_value}%` : `₹${Number(c.discount_value).toLocaleString()}`}</td>
                <td className="px-4 py-4">₹{Number(c.min_order_amount || 0).toLocaleString()}</td>
                <td className="px-4 py-4">{c.used_count || 0}/{c.usage_limit || '∞'}</td>
                <td className="px-4 py-4 text-sm text-gray-500">{c.valid_until ? new Date(c.valid_until).toLocaleDateString('en-IN') : '-'}</td>
                <td className="px-4 py-4"><span className={`px-3 py-1 rounded-full text-xs font-bold ${c.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>{c.is_active ? 'Active' : 'Inactive'}</span></td>
                <td className="px-4 py-4"><div className="flex gap-2">
                  <button onClick={() => handleEdit(c)} className="p-2 text-blue-600 hover:bg-blue-50 rounded"><Edit2 className="w-4 h-4" /></button>
                  <button onClick={() => handleDelete(c.id)} className="p-2 text-red-600 hover:bg-red-50 rounded"><Trash2 className="w-4 h-4" /></button>
                </div></td>
              </tr>
            ))}</tbody>
          </table>
        ); })()}
      </div>
      {showModal && (
        <Modal title={editingCoupon ? 'Edit Coupon' : 'Add Coupon'} onClose={() => setShowModal(false)}>
          <div className="grid grid-cols-2 gap-4">
            <div><label className="block text-sm font-bold mb-2">Code *</label><input type="text" className="input-field" value={formData.code} onChange={e => setFormData({ ...formData, code: e.target.value })} placeholder="SAVE20" /></div>
            <div><label className="block text-sm font-bold mb-2">Discount Type</label>
              <select className="input-field" value={formData.discount_type} onChange={e => setFormData({ ...formData, discount_type: e.target.value })}>
                <option value="percentage">Percentage</option>
                <option value="flat">Flat Amount</option>
              </select>
            </div>
            <div className="col-span-2"><label className="block text-sm font-bold mb-2">Description</label><input type="text" className="input-field" value={formData.description} onChange={e => setFormData({ ...formData, description: e.target.value })} placeholder="Coupon description" /></div>
            <div><label className="block text-sm font-bold mb-2">Discount Value *</label><input type="number" className="input-field" value={formData.discount_value} onChange={e => setFormData({ ...formData, discount_value: e.target.value })} placeholder={formData.discount_type === 'percentage' ? '10' : '500'} /></div>
            <div><label className="block text-sm font-bold mb-2">Min Order Amount</label><input type="number" className="input-field" value={formData.min_order_amount} onChange={e => setFormData({ ...formData, min_order_amount: e.target.value })} placeholder="0" /></div>
            <div><label className="block text-sm font-bold mb-2">Max Discount</label><input type="number" className="input-field" value={formData.max_discount} onChange={e => setFormData({ ...formData, max_discount: e.target.value })} placeholder="No limit" /></div>
            <div><label className="block text-sm font-bold mb-2">Usage Limit</label><input type="number" className="input-field" value={formData.usage_limit} onChange={e => setFormData({ ...formData, usage_limit: e.target.value })} placeholder="Unlimited" /></div>
            <div><label className="block text-sm font-bold mb-2">Valid From</label><input type="date" className="input-field" value={formData.valid_from} onChange={e => setFormData({ ...formData, valid_from: e.target.value })} /></div>
            <div><label className="block text-sm font-bold mb-2">Valid Until</label><input type="date" className="input-field" value={formData.valid_until} onChange={e => setFormData({ ...formData, valid_until: e.target.value })} /></div>
            {editingCoupon && (
              <div className="col-span-2"><label className="flex items-center gap-3 cursor-pointer"><input type="checkbox" checked={formData.is_active} onChange={e => setFormData({ ...formData, is_active: e.target.checked })} className="w-5 h-5 accent-mk-red" /><span className="text-sm font-bold">Active</span></label></div>
            )}
          </div>
          <div className="flex gap-3 mt-6">
            <button onClick={() => setShowModal(false)} className="flex-1 px-4 py-2 border-2 border-gray-300 rounded-lg hover:bg-gray-100 font-bold">Cancel</button>
            <button onClick={handleSave} disabled={saving} className="flex-1 btn-primary disabled:opacity-50">{saving ? 'Saving...' : editingCoupon ? 'Update Coupon' : 'Create Coupon'}</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ============================================================================
// ADMIN USERS MODULE - API-BACKED CRUD
// ============================================================================
function AdminUsersModule() {
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingUser, setEditingUser] = useState<AdminUser | null>(null);
  const [formData, setFormData] = useState({ firstName: '', lastName: '', email: '', phone: '', password: '', is_active: true as boolean, role: 'super_admin' });
  const [saving, setSaving] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  const availableRoles = ['super_admin', 'admin', 'manager', 'operator', 'viewer'];

  const loadData = async () => {
    try { const data = await adminUserService.getAll(); setUsers(data); }
    catch (err) { console.error('Failed to load admin users:', err); }
    finally { setLoading(false); }
  };

  useEffect(() => { loadData(); }, []);

  const handleAdd = () => { setEditingUser(null); setFormData({ firstName: '', lastName: '', email: '', phone: '', password: '', is_active: true, role: 'super_admin' }); setShowModal(true); };
  const handleEdit = (u: AdminUser) => {
    setEditingUser(u);
    setFormData({ firstName: u.first_name || '', lastName: u.last_name || '', email: u.email || '', phone: u.phone || '', password: '', is_active: u.is_active !== false, role: (u.roles && u.roles[0]) || 'super_admin' });
    setShowModal(true);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const body: Record<string, any> = { ...formData };
      if (editingUser && !body.password) delete body.password;
      if (editingUser) { await adminUserService.update(editingUser.id, body); }
      else { await adminUserService.create(body); }
      await loadData(); setShowModal(false);
    } catch (err) { console.error('Save admin user error:', err); alert('Failed to save admin user.'); }
    finally { setSaving(false); }
  };

  const handleDelete = async (id: string) => {
    if (confirm('Delete this admin user?')) {
      try { await adminUserService.delete(id); await loadData(); }
      catch (err) { console.error('Delete admin user error:', err); alert('Failed to delete admin user.'); }
    }
  };

  if (loading) return <LoadingSpinner />;

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-mk-gray">Admin Users</h1>
        <button onClick={handleAdd} className="btn-primary flex items-center gap-2"><Plus className="w-5 h-5" /> Add Admin User</button>
      </div>
      <div className="bg-white rounded-xl shadow-md p-6">
        <div className="flex items-center gap-3 mb-4"><div className="relative flex-1 max-w-md"><Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" /><input type="text" placeholder="Search by name or email..." className="input-field pl-10" value={searchTerm} onChange={e => setSearchTerm(e.target.value)} /></div></div>
        {(() => { const filtered = users.filter(u => !searchTerm || `${u.first_name} ${u.last_name}`.toLowerCase().includes(searchTerm.toLowerCase()) || u.email.toLowerCase().includes(searchTerm.toLowerCase())); return filtered.length === 0 ? <p className="text-gray-500 text-center py-8">No admin users found.</p> : (
          <table className="w-full">
            <thead className="bg-gray-50"><tr>
              <th className="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase">Name</th>
              <th className="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase">Email</th>
              <th className="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase">Phone</th>
              <th className="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase">Roles</th>
              <th className="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase">Status</th>
              <th className="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase">Last Login</th>
              <th className="px-6 py-3 text-left text-xs font-bold text-gray-600 uppercase">Actions</th>
            </tr></thead>
            <tbody>{filtered.map(u => (
              <tr key={u.id} className="border-t hover:bg-gray-50">
                <td className="px-6 py-4 font-bold">{u.first_name} {u.last_name || ''}</td>
                <td className="px-6 py-4 text-gray-600">{u.email}</td>
                <td className="px-6 py-4 text-gray-600">{u.phone || '-'}</td>
                <td className="px-6 py-4">{(u.roles || []).map((r, i) => <span key={i} className="px-2 py-1 bg-purple-100 text-purple-800 rounded-full text-xs font-bold mr-1">{r}</span>)}</td>
                <td className="px-6 py-4"><span className={`px-3 py-1 rounded-full text-xs font-bold ${u.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>{u.is_active ? 'Active' : 'Inactive'}</span></td>
                <td className="px-6 py-4 text-sm text-gray-500">{u.last_login_at ? new Date(u.last_login_at).toLocaleDateString('en-IN') : 'Never'}</td>
                <td className="px-6 py-4"><div className="flex gap-2">
                  <button onClick={() => handleEdit(u)} className="p-2 text-blue-600 hover:bg-blue-50 rounded"><Edit2 className="w-4 h-4" /></button>
                  <button onClick={() => handleDelete(u.id)} className="p-2 text-red-600 hover:bg-red-50 rounded"><Trash2 className="w-4 h-4" /></button>
                </div></td>
              </tr>
            ))}</tbody>
          </table>
        ); })()}
      </div>
      {showModal && (
        <Modal title={editingUser ? 'Edit Admin User' : 'Add Admin User'} onClose={() => setShowModal(false)}>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div><label className="block text-sm font-bold mb-2">First Name *</label><input type="text" className="input-field" value={formData.firstName} onChange={e => setFormData({ ...formData, firstName: e.target.value })} /></div>
              <div><label className="block text-sm font-bold mb-2">Last Name</label><input type="text" className="input-field" value={formData.lastName} onChange={e => setFormData({ ...formData, lastName: e.target.value })} /></div>
            </div>
            <div><label className="block text-sm font-bold mb-2">Email *</label><input type="email" className="input-field" value={formData.email} onChange={e => setFormData({ ...formData, email: e.target.value })} /></div>
            <div className="grid grid-cols-2 gap-4">
              <div><label className="block text-sm font-bold mb-2">Phone</label><input type="text" className="input-field" value={formData.phone} onChange={e => setFormData({ ...formData, phone: e.target.value })} /></div>
              <div><label className="block text-sm font-bold mb-2">Role</label>
                <select className="input-field" value={formData.role} onChange={e => setFormData({ ...formData, role: e.target.value })}>
                  {availableRoles.map(r => <option key={r} value={r}>{r.replace(/_/g, ' ').toUpperCase()}</option>)}
                </select>
              </div>
            </div>
            <div><label className="block text-sm font-bold mb-2">{editingUser ? 'New Password (leave blank to keep)' : 'Password *'}</label><input type="password" className="input-field" value={formData.password} onChange={e => setFormData({ ...formData, password: e.target.value })} /></div>
            {editingUser && (
              <div><label className="flex items-center gap-3 cursor-pointer"><input type="checkbox" checked={formData.is_active} onChange={e => setFormData({ ...formData, is_active: e.target.checked })} className="w-5 h-5 accent-mk-red" /><span className="text-sm font-bold">Active</span></label></div>
            )}
          </div>
          <div className="flex gap-3 mt-6">
            <button onClick={() => setShowModal(false)} className="flex-1 px-4 py-2 border-2 border-gray-300 rounded-lg hover:bg-gray-100 font-bold">Cancel</button>
            <button onClick={handleSave} disabled={saving} className="flex-1 btn-primary disabled:opacity-50">{saving ? 'Saving...' : editingUser ? 'Update User' : 'Create User'}</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ============================================================================
// INVENTORY MODULE - STOCK LEVELS, ALERTS, TRANSACTIONS
// ============================================================================
function InventoryModule() {
  const [tab, setTab] = useState<'stock' | 'alerts' | 'transactions'>('stock');
  const [stockItems, setStockItems] = useState<StockItem[]>([]);
  const [alertItems, setAlertItems] = useState<StockItem[]>([]);
  const [transactions, setTransactions] = useState<InventoryTransaction[]>([]);
  const [summary, setSummary] = useState<InventorySummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  // Stock adjustment modal
  const [showAdjustModal, setShowAdjustModal] = useState(false);
  const [adjustItem, setAdjustItem] = useState<StockItem | null>(null);
  const [adjustQty, setAdjustQty] = useState('');
  const [adjustReason, setAdjustReason] = useState('');
  const [saving, setSaving] = useState(false);

  const loadData = async () => {
    setLoading(true);
    try {
      const [stockData, alertData, txnData, summaryData] = await Promise.all([
        inventoryService.getStockLevels(),
        inventoryService.getStockLevels('low'),
        inventoryService.getTransactions(),
        inventoryService.getSummary(),
      ]);
      setStockItems(stockData);
      setAlertItems(alertData);
      setTransactions(txnData);
      setSummary(summaryData);
    } catch (err) {
      console.error('Failed to load inventory:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { loadData(); }, []);

  const handleAdjust = (item: StockItem) => {
    setAdjustItem(item);
    setAdjustQty(String(item.stock_qty));
    setAdjustReason('');
    setShowAdjustModal(true);
  };

  const handleSaveAdjust = async () => {
    if (!adjustItem) return;
    setSaving(true);
    try {
      await inventoryService.updateStock(adjustItem.id, Number(adjustQty), adjustReason || 'Manual stock adjustment');
      await loadData();
      setShowAdjustModal(false);
    } catch (err: any) {
      console.error('Stock adjust error:', err);
      alert(err?.response?.data?.message || 'Failed to update stock.');
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <LoadingSpinner />;

  const stockStatusBadge = (status: string) => {
    const colors: Record<string, string> = {
      out_of_stock: 'bg-red-100 text-red-800',
      low_stock: 'bg-yellow-100 text-yellow-800',
      in_stock: 'bg-green-100 text-green-800',
    };
    const labels: Record<string, string> = {
      out_of_stock: 'Out of Stock',
      low_stock: 'Low Stock',
      in_stock: 'In Stock',
    };
    return <span className={`px-3 py-1 rounded-full text-xs font-bold ${colors[status] || 'bg-gray-100'}`}>{labels[status] || status}</span>;
  };

  const txnTypeBadge = (type: string) => {
    const colors: Record<string, string> = {
      add: 'bg-green-100 text-green-800',
      reduce: 'bg-red-100 text-red-800',
      reserve: 'bg-yellow-100 text-yellow-800',
      adjust: 'bg-blue-100 text-blue-800',
    };
    return <span className={`px-2 py-1 rounded-full text-xs font-bold ${colors[type] || 'bg-gray-100'}`}>{type.toUpperCase()}</span>;
  };

  const filteredStock = stockItems.filter(item =>
    !searchTerm || item.name.toLowerCase().includes(searchTerm.toLowerCase()) || (item.sku && item.sku.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-mk-gray">Inventory Management</h1>
        <button onClick={loadData} className="flex items-center gap-2 px-4 py-2 border-2 border-gray-300 rounded-lg hover:bg-gray-100 font-bold text-sm">
          <RefreshCw className="w-4 h-4" /> Refresh
        </button>
      </div>

      {/* Summary Cards */}
      {summary && (
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 mb-6">
          <div className="bg-white rounded-xl shadow-md p-4 text-center">
            <Package className="w-6 h-6 text-blue-500 mx-auto mb-1" />
            <p className="text-2xl font-bold">{Number(summary.total_products).toLocaleString()}</p>
            <p className="text-xs text-gray-500">Total Products</p>
          </div>
          <div className="bg-white rounded-xl shadow-md p-4 text-center">
            <PackageCheck className="w-6 h-6 text-green-500 mx-auto mb-1" />
            <p className="text-2xl font-bold text-green-600">{Number(summary.in_stock).toLocaleString()}</p>
            <p className="text-xs text-gray-500">In Stock</p>
          </div>
          <div className="bg-white rounded-xl shadow-md p-4 text-center">
            <TrendingDown className="w-6 h-6 text-yellow-500 mx-auto mb-1" />
            <p className="text-2xl font-bold text-yellow-600">{Number(summary.low_stock).toLocaleString()}</p>
            <p className="text-xs text-gray-500">Low Stock</p>
          </div>
          <div className="bg-white rounded-xl shadow-md p-4 text-center">
            <PackageX className="w-6 h-6 text-red-500 mx-auto mb-1" />
            <p className="text-2xl font-bold text-red-600">{Number(summary.out_of_stock).toLocaleString()}</p>
            <p className="text-xs text-gray-500">Out of Stock</p>
          </div>
          <div className="bg-white rounded-xl shadow-md p-4 text-center">
            <Boxes className="w-6 h-6 text-purple-500 mx-auto mb-1" />
            <p className="text-2xl font-bold">{Number(summary.total_units || 0).toLocaleString()}</p>
            <p className="text-xs text-gray-500">Total Units</p>
          </div>
          <div className="bg-white rounded-xl shadow-md p-4 text-center">
            <DollarSign className="w-6 h-6 text-indigo-500 mx-auto mb-1" />
            <p className="text-2xl font-bold">₹{Number(summary.total_stock_value || 0).toLocaleString()}</p>
            <p className="text-xs text-gray-500">Stock Value</p>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="flex gap-1 mb-4 bg-gray-100 rounded-lg p-1 w-fit">
        {([
          { id: 'stock' as const, label: 'All Stock', icon: Package },
          { id: 'alerts' as const, label: `Low Stock Alerts (${alertItems.length})`, icon: AlertCircle },
          { id: 'transactions' as const, label: 'Transaction History', icon: ArrowUpDown },
        ]).map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-bold transition ${tab === t.id ? 'bg-white shadow text-mk-red' : 'text-gray-600 hover:text-gray-800'}`}>
            <t.icon className="w-4 h-4" /> {t.label}
          </button>
        ))}
      </div>

      {/* Stock Levels Tab */}
      {tab === 'stock' && (
        <div className="bg-white rounded-xl shadow-md p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="relative flex-1 max-w-md">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
              <input type="text" placeholder="Search by name or SKU..." className="input-field pl-10"
                value={searchTerm} onChange={e => setSearchTerm(e.target.value)} />
            </div>
          </div>
          {filteredStock.length === 0 ? <p className="text-gray-500 text-center py-8">No products found.</p> : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50"><tr>
                  <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Product</th>
                  <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">SKU</th>
                  <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Category</th>
                  <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Brand</th>
                  <th className="px-4 py-3 text-right text-xs font-bold text-gray-600 uppercase">Stock Qty</th>
                  <th className="px-4 py-3 text-right text-xs font-bold text-gray-600 uppercase">Price</th>
                  <th className="px-4 py-3 text-center text-xs font-bold text-gray-600 uppercase">Status</th>
                  <th className="px-4 py-3 text-center text-xs font-bold text-gray-600 uppercase">Actions</th>
                </tr></thead>
                <tbody>{filteredStock.map(item => (
                  <tr key={item.id} className="border-t hover:bg-gray-50">
                    <td className="px-4 py-3 font-bold text-sm">{item.name}</td>
                    <td className="px-4 py-3 text-sm text-gray-600">{item.sku || '-'}</td>
                    <td className="px-4 py-3 text-sm">{item.category_name || '-'}</td>
                    <td className="px-4 py-3 text-sm">{item.brand_name || '-'}</td>
                    <td className={`px-4 py-3 text-right font-bold ${item.stock_qty <= 0 ? 'text-red-600' : item.stock_qty <= 10 ? 'text-yellow-600' : 'text-green-600'}`}>{item.stock_qty}</td>
                    <td className="px-4 py-3 text-right text-sm">₹{Number(item.price).toLocaleString()}</td>
                    <td className="px-4 py-3 text-center">{stockStatusBadge(item.stock_status)}</td>
                    <td className="px-4 py-3 text-center">
                      <button onClick={() => handleAdjust(item)} className="p-2 text-blue-600 hover:bg-blue-50 rounded" title="Adjust Stock">
                        <Edit2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}</tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Low Stock Alerts Tab */}
      {tab === 'alerts' && (
        <div className="bg-white rounded-xl shadow-md p-6">
          {alertItems.length === 0 ? (
            <div className="text-center py-12">
              <PackageCheck className="w-12 h-12 text-green-400 mx-auto mb-3" />
              <p className="text-gray-500 font-bold">All stock levels are healthy!</p>
              <p className="text-sm text-gray-400 mt-1">No products below the low-stock threshold (10 units).</p>
            </div>
          ) : (
            <div className="space-y-3">
              {alertItems.map(item => (
                <div key={item.id} className={`flex items-center justify-between p-4 rounded-lg border-l-4 ${item.stock_qty <= 0 ? 'bg-red-50 border-red-500' : 'bg-yellow-50 border-yellow-500'}`}>
                  <div className="flex-1">
                    <p className="font-bold text-sm">{item.name}</p>
                    <p className="text-xs text-gray-500">{item.sku || 'No SKU'} {item.category_name ? `· ${item.category_name}` : ''} {item.brand_name ? `· ${item.brand_name}` : ''}</p>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <p className={`text-lg font-bold ${item.stock_qty <= 0 ? 'text-red-600' : 'text-yellow-600'}`}>{item.stock_qty}</p>
                      <p className="text-xs text-gray-500">units left</p>
                    </div>
                    {stockStatusBadge(item.stock_status)}
                    <button onClick={() => handleAdjust(item)} className="px-3 py-1.5 bg-blue-600 text-white text-xs font-bold rounded-lg hover:bg-blue-700">
                      Restock
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Transactions Tab */}
      {tab === 'transactions' && (
        <div className="bg-white rounded-xl shadow-md p-6">
          {transactions.length === 0 ? <p className="text-gray-500 text-center py-8">No inventory transactions found.</p> : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50"><tr>
                  <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Date</th>
                  <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Product</th>
                  <th className="px-4 py-3 text-center text-xs font-bold text-gray-600 uppercase">Type</th>
                  <th className="px-4 py-3 text-right text-xs font-bold text-gray-600 uppercase">Change</th>
                  <th className="px-4 py-3 text-right text-xs font-bold text-gray-600 uppercase">Before</th>
                  <th className="px-4 py-3 text-right text-xs font-bold text-gray-600 uppercase">After</th>
                  <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Reason</th>
                  <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Reference</th>
                </tr></thead>
                <tbody>{transactions.map(txn => (
                  <tr key={txn.id} className="border-t hover:bg-gray-50">
                    <td className="px-4 py-3 text-sm">{new Date(txn.created_at).toLocaleString()}</td>
                    <td className="px-4 py-3 text-sm"><span className="font-bold">{txn.product_name}</span>{txn.sku && <span className="text-gray-400 ml-1">({txn.sku})</span>}</td>
                    <td className="px-4 py-3 text-center">{txnTypeBadge(txn.transaction_type)}</td>
                    <td className={`px-4 py-3 text-right font-bold ${txn.quantity_change >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {txn.quantity_change >= 0 ? '+' : ''}{txn.quantity_change}
                    </td>
                    <td className="px-4 py-3 text-right text-sm text-gray-500">{txn.quantity_before}</td>
                    <td className="px-4 py-3 text-right text-sm font-bold">{txn.quantity_after}</td>
                    <td className="px-4 py-3 text-sm text-gray-600">{txn.reason || '-'}</td>
                    <td className="px-4 py-3 text-sm text-gray-500">{txn.reference_type ? `${txn.reference_type} #${txn.reference_id}` : '-'}</td>
                  </tr>
                ))}</tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Stock Adjustment Modal */}
      {showAdjustModal && adjustItem && (
        <Modal title={`Adjust Stock — ${adjustItem.name}`} onClose={() => setShowAdjustModal(false)}>
          <div className="space-y-4">
            <div className="bg-gray-50 p-4 rounded-lg text-sm space-y-1">
              <p><span className="font-bold">SKU:</span> {adjustItem.sku || '-'}</p>
              <p><span className="font-bold">Current Stock:</span> <span className={adjustItem.stock_qty <= 0 ? 'text-red-600 font-bold' : 'font-bold'}>{adjustItem.stock_qty} units</span></p>
            </div>
            <div>
              <label className="block text-sm font-bold mb-2">New Stock Quantity *</label>
              <input type="number" min="0" className="input-field" value={adjustQty} onChange={e => setAdjustQty(e.target.value)} />
              {adjustQty !== '' && Number(adjustQty) !== adjustItem.stock_qty && (
                <p className={`text-sm mt-1 font-bold ${Number(adjustQty) > adjustItem.stock_qty ? 'text-green-600' : 'text-red-600'}`}>
                  {Number(adjustQty) > adjustItem.stock_qty ? '+' : ''}{Number(adjustQty) - adjustItem.stock_qty} units change
                </p>
              )}
            </div>
            <div>
              <label className="block text-sm font-bold mb-2">Reason</label>
              <input type="text" className="input-field" placeholder="e.g. New shipment received, Damaged goods removed" value={adjustReason} onChange={e => setAdjustReason(e.target.value)} />
            </div>
          </div>
          <div className="flex gap-3 mt-6">
            <button onClick={() => setShowAdjustModal(false)} className="flex-1 px-4 py-2 border-2 border-gray-300 rounded-lg hover:bg-gray-100 font-bold">Cancel</button>
            <button onClick={handleSaveAdjust} disabled={saving || adjustQty === ''} className="flex-1 btn-primary disabled:opacity-50">{saving ? 'Updating...' : 'Update Stock'}</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ============================================================================
// COUPONS MODULE
// ============================================================================
function CouponsModule() {
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingItem, setEditingItem] = useState<Coupon | null>(null);
  const [formData, setFormData] = useState({
    code: '', description: '', discount_type: 'percentage' as 'percentage' | 'fixed',
    discount_value: '', min_order_amount: '0', max_discount: '',
    usage_limit: '', valid_from: '', valid_until: '', is_active: true
  });
  const [saving, setSaving] = useState(false);

  const loadData = async () => {
    try {
      const data = await couponService.getAll();
      setCoupons(Array.isArray(data) ? data : []);
    } catch (err) { console.error('Failed to load coupons:', err); }
    finally { setLoading(false); }
  };

  useEffect(() => { loadData(); }, []);

  const handleAdd = () => {
    setEditingItem(null);
    setFormData({ code: '', description: '', discount_type: 'percentage', discount_value: '', min_order_amount: '0', max_discount: '', usage_limit: '', valid_from: new Date().toISOString().slice(0, 10), valid_until: '', is_active: true });
    setShowModal(true);
  };

  const handleEdit = (item: Coupon) => {
    setEditingItem(item);
    setFormData({
      code: item.code, description: item.description || '', discount_type: item.discount_type,
      discount_value: String(item.discount_value), min_order_amount: String(item.min_order_amount || 0),
      max_discount: item.max_discount ? String(item.max_discount) : '',
      usage_limit: item.usage_limit ? String(item.usage_limit) : '',
      valid_from: item.valid_from ? item.valid_from.slice(0, 10) : '',
      valid_until: item.valid_until ? item.valid_until.slice(0, 10) : '',
      is_active: item.is_active
    });
    setShowModal(true);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const payload = {
        ...formData,
        discount_value: Number(formData.discount_value),
        min_order_amount: Number(formData.min_order_amount) || 0,
        max_discount: formData.max_discount ? Number(formData.max_discount) : null,
        usage_limit: formData.usage_limit ? Number(formData.usage_limit) : null,
        valid_from: formData.valid_from || null,
        valid_until: formData.valid_until || null,
      };
      if (editingItem) { await couponService.update(editingItem.id, payload); }
      else { await couponService.create(payload); }
      await loadData(); setShowModal(false);
    } catch (err) { console.error('Save coupon error:', err); alert('Failed to save coupon.'); }
    finally { setSaving(false); }
  };

  const handleDelete = async (id: string) => {
    if (confirm('Delete this coupon?')) {
      try { await couponService.delete(id); await loadData(); }
      catch (err) { console.error('Delete coupon error:', err); alert('Failed to delete coupon.'); }
    }
  };

  if (loading) return <LoadingSpinner />;

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-mk-gray">Coupons</h1>
        <button onClick={handleAdd} className="btn-primary flex items-center gap-2"><Plus className="w-5 h-5" /> Add Coupon</button>
      </div>
      <div className="bg-white rounded-xl shadow-md p-6">
        {coupons.length === 0 ? <p className="text-gray-500 text-center py-8">No coupons found.</p> : (
          <table className="w-full">
            <thead className="bg-gray-50"><tr>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Code</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Type</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Value</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Min Order</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Usage</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Valid Until</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Status</th>
              <th className="px-4 py-3 text-left text-xs font-bold text-gray-600 uppercase">Actions</th>
            </tr></thead>
            <tbody>{coupons.map(c => (
              <tr key={c.id} className="border-t hover:bg-gray-50">
                <td className="px-4 py-3 font-bold font-mono">{c.code}</td>
                <td className="px-4 py-3 text-sm">{c.discount_type === 'percentage' ? 'Percentage' : 'Fixed'}</td>
                <td className="px-4 py-3 text-sm font-bold">{c.discount_type === 'percentage' ? `${c.discount_value}%` : `₹${c.discount_value}`}{c.max_discount ? ` (max ₹${c.max_discount})` : ''}</td>
                <td className="px-4 py-3 text-sm">₹{Number(c.min_order_amount).toLocaleString()}</td>
                <td className="px-4 py-3 text-sm">{c.used_count}{c.usage_limit ? `/${c.usage_limit}` : '/∞'}</td>
                <td className="px-4 py-3 text-sm">{c.valid_until ? new Date(c.valid_until).toLocaleDateString() : 'No expiry'}</td>
                <td className="px-4 py-3"><span className={`px-3 py-1 rounded-full text-xs font-bold ${c.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>{c.is_active ? 'Active' : 'Inactive'}</span></td>
                <td className="px-4 py-3"><div className="flex gap-2">
                  <button onClick={() => handleEdit(c)} className="p-2 text-blue-600 hover:bg-blue-50 rounded"><Edit2 className="w-4 h-4" /></button>
                  <button onClick={() => handleDelete(c.id)} className="p-2 text-red-600 hover:bg-red-50 rounded"><Trash2 className="w-4 h-4" /></button>
                </div></td>
              </tr>
            ))}</tbody>
          </table>
        )}
      </div>
      {showModal && (
        <Modal title={editingItem ? 'Edit Coupon' : 'Add Coupon'} onClose={() => setShowModal(false)}>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div><label className="block text-sm font-bold mb-2">Coupon Code *</label><input type="text" className="input-field uppercase" value={formData.code} onChange={e => setFormData({ ...formData, code: e.target.value.toUpperCase() })} placeholder="SAVE20" /></div>
              <div><label className="block text-sm font-bold mb-2">Discount Type</label><select className="input-field" value={formData.discount_type} onChange={e => setFormData({ ...formData, discount_type: e.target.value as any })}><option value="percentage">Percentage</option><option value="fixed">Fixed Amount</option></select></div>
            </div>
            <div><label className="block text-sm font-bold mb-2">Description</label><input type="text" className="input-field" value={formData.description} onChange={e => setFormData({ ...formData, description: e.target.value })} placeholder="Save 20% on your order" /></div>
            <div className="grid grid-cols-3 gap-4">
              <div><label className="block text-sm font-bold mb-2">{formData.discount_type === 'percentage' ? 'Discount %' : 'Discount ₹'} *</label><input type="number" className="input-field" value={formData.discount_value} onChange={e => setFormData({ ...formData, discount_value: e.target.value })} /></div>
              <div><label className="block text-sm font-bold mb-2">Min Order ₹</label><input type="number" className="input-field" value={formData.min_order_amount} onChange={e => setFormData({ ...formData, min_order_amount: e.target.value })} /></div>
              <div><label className="block text-sm font-bold mb-2">Max Discount ₹</label><input type="number" className="input-field" value={formData.max_discount} onChange={e => setFormData({ ...formData, max_discount: e.target.value })} placeholder="Optional" /></div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div><label className="block text-sm font-bold mb-2">Usage Limit</label><input type="number" className="input-field" value={formData.usage_limit} onChange={e => setFormData({ ...formData, usage_limit: e.target.value })} placeholder="Unlimited" /></div>
              <div><label className="block text-sm font-bold mb-2">Valid From</label><input type="date" className="input-field" value={formData.valid_from} onChange={e => setFormData({ ...formData, valid_from: e.target.value })} /></div>
              <div><label className="block text-sm font-bold mb-2">Valid Until</label><input type="date" className="input-field" value={formData.valid_until} onChange={e => setFormData({ ...formData, valid_until: e.target.value })} placeholder="No expiry" /></div>
            </div>
            {editingItem && (
              <div><label className="flex items-center gap-2 cursor-pointer"><input type="checkbox" checked={formData.is_active} onChange={e => setFormData({ ...formData, is_active: e.target.checked })} className="w-4 h-4" /><span className="text-sm font-bold">Active</span></label></div>
            )}
          </div>
          <div className="flex gap-3 mt-6">
            <button onClick={() => setShowModal(false)} className="flex-1 px-4 py-2 border-2 border-gray-300 rounded-lg hover:bg-gray-100 font-bold">Cancel</button>
            <button onClick={handleSave} disabled={saving} className="flex-1 btn-primary disabled:opacity-50">{saving ? 'Saving...' : 'Save Coupon'}</button>
          </div>
        </Modal>
      )}
    </div>
  );
}

// ============================================================================
// MODAL COMPONENT
// ============================================================================
function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-60 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl">
        <div className="flex items-center justify-between p-6 border-b-2">
          <h2 className="text-2xl font-bold text-mk-gray">{title}</h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-lg"><X className="w-6 h-6" /></button>
        </div>
        <div className="p-6">{children}</div>
      </div>
    </div>
  );
}
